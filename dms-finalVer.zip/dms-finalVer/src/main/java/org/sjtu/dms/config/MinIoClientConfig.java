package org.sjtu.dms.config;

import io.minio.MinioClient;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * MinIo链接配置
 */
@Getter
@Setter
@Component
@RequiredArgsConstructor
public class MinIoClientConfig {
    private final MinIoProperties minIoProperties;

    /**
     * 注入minio 客户端
     */
    @Bean
    public MinioClient minioClient() {
        return MinioClient.builder()
                .endpoint(minIoProperties.getEndpoint())
                .credentials(minIoProperties.getAccessKey(), minIoProperties.getAccessKey())
                .build();
    }
}
