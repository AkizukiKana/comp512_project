package org.sjtu.dms.service.dto;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
    private Long id;
    private String userName;
    private String name;
    private String emailAddress;
    private String phoneNumber;
}
