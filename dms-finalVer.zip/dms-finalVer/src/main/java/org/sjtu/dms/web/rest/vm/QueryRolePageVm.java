package org.sjtu.dms.web.rest.vm;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.sjtu.dms.shared.model.PagedAndSorted;
import org.sjtu.dms.shared.model.ShouldNormalize;

@Getter
@Setter
public class QueryRolePageVm extends PagedAndSorted implements ShouldNormalize {
    private String filter;

    @Override
    public void normalize() {
        if (StringUtils.isBlank(super.getSort())) {
            super.setSort("id");
        }
    }
}
