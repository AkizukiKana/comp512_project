package org.sjtu.dms.shared.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

@Getter
@Setter
public class PagedAndSorted extends Sorted {
    private Integer page = Paged.PAGE;
    private Integer size = Paged.SIZE;

    public Pageable buildPageable() {
        return PageRequest.of(page, size, buildSort());
    }

    public Pageable buildPageable(String defaultSort) {
        return buildPageable(defaultSort, false);
    }

    public Pageable buildPageable(String defaultSort, boolean alwaysDefault) {
        return PageRequest.of(page, size, buildSort(defaultSort, alwaysDefault));
    }
}
