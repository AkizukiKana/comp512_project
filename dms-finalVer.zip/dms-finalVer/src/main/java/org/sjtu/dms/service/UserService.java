package org.sjtu.dms.service;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.sjtu.dms.config.SystemConstants;
import org.sjtu.dms.config.UserInfoContext;
import org.sjtu.dms.domain.Role;
import org.sjtu.dms.domain.User;
import org.sjtu.dms.domain.UserRole;
import org.sjtu.dms.repository.RoleRepository;
import org.sjtu.dms.repository.UserRepository;
import org.sjtu.dms.repository.UserRoleRepository;
import org.sjtu.dms.service.dto.UserDto;
import org.sjtu.dms.service.dto.UserEditDto;
import org.sjtu.dms.web.rest.vm.CreateUserVm;
import org.sjtu.dms.web.rest.vm.QueryUserPageVm;
import org.sjtu.dms.web.rest.vm.UpdateUserVm;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.Predicate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final UserRoleRepository userRoleRepository;

    public UserService(UserRepository userRepository,
                       RoleRepository roleRepository,
                       UserRoleRepository userRoleRepository) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.userRoleRepository = userRoleRepository;
    }

    public void create(CreateUserVm param) {
        String userName = param.getUserName();
        Optional<User> existUser = userRepository.findByUserName(userName);
        if (existUser.isPresent()) {
            throw new RuntimeException(String.format("用户名:%s, 用户已存在不能重复创建", userName));
        }

        User user = new User();
        user.setUserName(userName);
        user.setPassword(param.getPassword());
        user.setName(param.getName());
        user.setEmailAddress(param.getEmailAddress());
        user.setPhoneNumber(param.getPhoneNumber());
        user = userRepository.save(user);

        List<String> roleNameList = param.getAssignedRoleNameList();
        List<Role> roleList = roleRepository.findByNameIn(roleNameList);
        if (CollectionUtils.isNotEmpty(roleList)) {
            saveUserRole(user.getId(), roleList.stream().map(Role::getId).collect(Collectors.toList()));
        }
    }

    private void saveUserRole(Long userId, List<Long> roleIdList) {
        List<UserRole> userRoleList = roleIdList.stream().map(roleId -> {
            UserRole userRole = new UserRole();
            userRole.setUserId(userId);
            userRole.setRoleId(roleId);
            return userRole;
        }).collect(Collectors.toList());
        userRoleRepository.saveAll(userRoleList);
    }

    public Page<UserDto> getUserPage(QueryUserPageVm param) {
        Specification<User> spec = (root, query, build) -> {
            List<Predicate> predicateList = new ArrayList<>();
            if (StringUtils.isNotBlank(param.getFilter())) {
                predicateList.add(build.or(
                        build.like(root.get("userName"), String.format("%%%s%%", param.getFilter())),
                        build.like(root.get("name"), String.format("%%%s%%", param.getFilter())),
                        build.like(root.get("emailAddress"), String.format("%%%s%%", param.getFilter()))));
            }
            return build.and(predicateList.toArray(new Predicate[0]));
        };
        Page<User> userPage = userRepository.findAll(spec, param.buildPageable());
        return userPage.map(s -> {
            UserDto dto = new UserDto();
            dto.setId(s.getId());
            dto.setUserName(s.getUserName());
            dto.setName(s.getName());
            dto.setEmailAddress(s.getEmailAddress());
            dto.setPhoneNumber(s.getPhoneNumber());
            return dto;
        });
    }

    public void update(UpdateUserVm param) {
        User user = userRepository.findById(param.getId()).orElseThrow(() -> new RuntimeException("用户不存在, 无法更新"));
        user.setPassword(param.getPassword());
        user.setName(param.getName());
        user.setEmailAddress(param.getEmailAddress());
        user.setPhoneNumber(param.getPhoneNumber());
        userRepository.save(user);

        List<String> roleNameList = param.getAssignedRoleNameList();
        if (SystemConstants.ADMIN_USER.equals(user.getUserName()) &&
                roleNameList.stream().noneMatch(SystemConstants.ADMIN_ROLE::equalsIgnoreCase)) {
            throw new RuntimeException("管理员角色无法从管理员用户中删除");
        }

        List<UserRole> userRoleList = userRoleRepository.findByUserId(user.getId());
        if (CollectionUtils.isNotEmpty(userRoleList)) {
            List<Role> roleList = roleRepository.findAllById(userRoleList.stream().map(UserRole::getRoleId).collect(Collectors.toList()));
            List<Long> deleteRoleIdList = roleList.stream().map(role -> {
                if (roleNameList.contains(role.getName())) {
                    roleNameList.remove(role.getName());
                    return null;
                } else {
                    return role.getId();
                }
            }).filter(Objects::nonNull).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(deleteRoleIdList)) {
                userRoleRepository.deleteAll(userRoleList.stream().filter(s -> deleteRoleIdList.contains(s.getRoleId())).collect(Collectors.toList()));
            }
        }

        List<Role> roleList = roleRepository.findByNameIn(roleNameList);
        if (CollectionUtils.isNotEmpty(roleList)) {
            saveUserRole(user.getId(), roleList.stream().map(Role::getId).collect(Collectors.toList()));
        }
    }

    public void delete(Long id) {
        Long currentUserId = UserInfoContext.getCurrentUserId();
        if (Objects.equals(currentUserId, id)) {
            throw new RuntimeException("您不能删除自己的用户帐户");
        }

        Optional<User> userOptional = userRepository.findById(id);
        if (!userOptional.isPresent()) {
            return;
        }
        User user = userOptional.get();
        if (SystemConstants.ADMIN_USER.equalsIgnoreCase(user.getUserName())) {
            throw new RuntimeException("不能删除默认管理员");
        }

        userRepository.deleteById(id);
    }

    public UserEditDto getUserEdit(Long id) {
        Optional<User> userOptional = userRepository.findById(id);
        if (!userOptional.isPresent()) {
            throw new RuntimeException("用户不存在");
        }
        User user = userOptional.get();

        UserEditDto result = new UserEditDto();
        result.setId(user.getId());
        result.setUserName(user.getUserName());
        result.setPassword(user.getPassword());
        result.setName(user.getName());
        result.setEmailAddress(user.getEmailAddress());
        result.setPhoneNumber(user.getPhoneNumber());
        List<UserRole> userRoleList = userRoleRepository.findByUserId(user.getId());
        if (CollectionUtils.isNotEmpty(userRoleList)) {
            List<Role> roleList = roleRepository.findAllById(userRoleList.stream().map(UserRole::getRoleId).collect(Collectors.toList()));
            result.setAssignedRoleNameList(roleList.stream().map(Role::getName).collect(Collectors.toList()));
        }
        return result;
    }
}
