package org.sjtu.dms.shared.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.io.Serializable;

@Getter
@Setter
public class Paged implements Serializable {
    private static final long serialVersionUID = -7573870237775343782L;
    public static final int PAGE = 0;
    public static final int SIZE = 10;
    private Integer page = PAGE;
    private Integer size = SIZE;

    public Pageable buildPageable() {
        return PageRequest.of(page, size, Sort.unsorted());
    }

    public Pageable buildPageable(Sort sort) {
        return PageRequest.of(page, size, sort);
    }
}
