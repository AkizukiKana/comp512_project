package org.sjtu.dms.shared.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import org.springframework.data.domain.Page;

import java.util.ArrayList;
import java.util.List;

@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class PageResult<T> extends ListResult<T> {
    /**
     * 每页条数
     */
    private final int pageSize;
    /**
     * 当前页：从0开始
     */
    private final int currentPage;
    /**
     * 具体内容
     */
    private final List<T> items;

    public PageResult(long total, int pageSize, int currentPage, List<T> items) {
        super(total, items);
        this.pageSize = pageSize;
        this.currentPage = currentPage;
        this.items = items;
    }

    public static <T> PageResult<T> create(Page<T> page) {
        if (null != page) {
            return new PageResult<>(page.getTotalElements(), page.getSize(), page.getNumber(), page.getContent());
        } else {
            return new PageResult<>(0, 0, 0, new ArrayList<>());
        }
    }
}
