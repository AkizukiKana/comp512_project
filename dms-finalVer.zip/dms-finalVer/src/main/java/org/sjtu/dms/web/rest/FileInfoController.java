package org.sjtu.dms.web.rest;

import org.apache.commons.collections4.CollectionUtils;
import org.sjtu.dms.service.FileInfoService;
import org.sjtu.dms.service.dto.FileInfoDto;
import org.sjtu.dms.shared.model.PageResult;
import org.sjtu.dms.web.rest.vm.QueryFileInfoPageVm;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping("/api/fileInfo")
public class FileInfoController {
    private final FileInfoService fileInfoService;

    public FileInfoController(FileInfoService fileInfoService) {
        this.fileInfoService = fileInfoService;
    }

    /**
     * 分页查询本人上传文件
     */
    @GetMapping("/page")
    public PageResult<FileInfoDto> getUserPage(QueryFileInfoPageVm param) {
        return PageResult.create(fileInfoService.getFileInfoPage(param));
    }

    /**
     * 上传文件
     */
    @PostMapping("/upload")
    public String upload(List<MultipartFile> files) {
        if (CollectionUtils.isEmpty(files)) {
            return "请选择文件";
        }
        fileInfoService.upload(files);
        return "上传中，请稍等刷新页面";
    }

    /**
     * 下载文件
     */
    @GetMapping("/download")
    public void download(@RequestParam Long fileInfoId, HttpServletResponse response) {
        fileInfoService.download(fileInfoId, response);
    }

    /**
     * 共享文件
     */
    @PostMapping("/openShare")
    public void openShare(@RequestParam Long fileInfoId) {
        fileInfoService.openShare(fileInfoId);
    }

    /**
     * 关闭共享
     */
    @PostMapping("/closeShare")
    public void closeShare(@RequestParam Long fileInfoId) {
        fileInfoService.closeShare(fileInfoId);
    }

    /**
     * 分页查询他人共享的文件
     */
    @GetMapping("/sharePage")
    public PageResult<FileInfoDto> getSharePage(QueryFileInfoPageVm param) {
        return PageResult.create(fileInfoService.getSharePage(param));
    }

    /**
     * 删除文件
     */
    @DeleteMapping("/remove")
    public void remove(@RequestParam Long fileInfoId) {
        fileInfoService.remove(fileInfoId);
    }
}
