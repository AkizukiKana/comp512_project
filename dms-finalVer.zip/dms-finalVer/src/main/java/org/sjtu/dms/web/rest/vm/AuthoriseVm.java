package org.sjtu.dms.web.rest.vm;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AuthoriseVm {
    private String userName;
    private String password;
    private boolean rememberMe;
}
