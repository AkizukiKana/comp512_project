package org.sjtu.dms.service.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
public class UserEditDto {
    private Long id;
    private String userName;
    private String password;
    private String name;
    private String emailAddress;
    private String phoneNumber;
    private List<String> assignedRoleNameList;
}
