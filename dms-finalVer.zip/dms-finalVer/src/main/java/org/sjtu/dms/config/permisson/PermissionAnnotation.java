package org.sjtu.dms.config.permisson;

import java.lang.annotation.*;

/**
 * 指定方法访问控制 注解
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface PermissionAnnotation {
    String value();
}
