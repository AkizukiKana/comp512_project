package org.sjtu.dms.web.rest;

import org.sjtu.dms.service.AuthService;
import org.sjtu.dms.service.dto.LogInDto;
import org.sjtu.dms.web.rest.vm.AuthoriseVm;
import org.sjtu.dms.web.rest.vm.LoginVm;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    /**
     * Obtain token
     */
    @PostMapping("/authorise")
    public String authorise(@RequestBody AuthoriseVm param) {
        return authService.authorise(param.getUserName(), param.getPassword(), param.isRememberMe());
    }

    /**
     * Login
     */
    @PostMapping("/login")
    public LogInDto login(@RequestBody LoginVm param) {
        return authService.login(param.getUserName(), param.getPassword(), param.isRememberMe());
    }
}
