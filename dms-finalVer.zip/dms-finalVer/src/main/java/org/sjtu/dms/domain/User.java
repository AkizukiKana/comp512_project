package org.sjtu.dms.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@ToString
@Entity
@Table(name = "t_sys_users")
public class User {
    private static final long serialVersionUID = -5384718272522282637L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private Long id;

    @Column(name = "user_name", columnDefinition = "varchar(256) not null")
    private String userName;

    @Column(name = "password", columnDefinition = "varchar(128) not null")
    private String password;

    @Column(name = "name", columnDefinition = "varchar(64) not null")
    private String name;

    @Column(name = "email_address", columnDefinition = "varchar(256) not null")
    private String emailAddress;

    private String phoneNumber;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
    @Fetch(FetchMode.SUBSELECT)
    private List<UserRole> userRoleList;
}
