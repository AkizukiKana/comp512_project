package org.sjtu.dms.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.List;

/**
 * @author WHW 2020-12
 */
@Getter
@Setter
@Entity
@Table(name = "t_sys_roles")
public class Role  {
    private static final long serialVersionUID = 4390085859787751823L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private Long id;

    @Column(name = "name", columnDefinition = "varchar(64) not null")
    private String name;

    @Column(name = "display_name", columnDefinition = "varchar(64) not null")
    private String displayName;

    @Version
    @Column(name = "version", columnDefinition = "int not null default '0'")
    @JsonIgnore
    private int version = 0;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "role")
    @Fetch(FetchMode.SUBSELECT)
    private List<UserRole> userRoleList;
}
