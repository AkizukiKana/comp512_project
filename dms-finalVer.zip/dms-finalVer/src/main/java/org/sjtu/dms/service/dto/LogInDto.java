package org.sjtu.dms.service.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class LogInDto {
    private String userName;
    private String name;
    private String token;
    private List<String> grantedPermissionList;
    private List<MenuDto> menuList;
}
