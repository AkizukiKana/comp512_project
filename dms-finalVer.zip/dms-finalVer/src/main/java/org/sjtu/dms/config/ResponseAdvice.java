package org.sjtu.dms.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.jetbrains.annotations.NotNull;
import org.sjtu.dms.shared.model.Result;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.util.Objects;

/**
 * restController返回数据全局统一处理
 */
@RestControllerAdvice
public class ResponseAdvice implements ResponseBodyAdvice<Object> {
    @Override
    public boolean supports(@NotNull MethodParameter methodParameter, @NotNull Class clazz) {
        Class<?> parameterType = methodParameter.getParameterType();
        return parameterType != ResponseEntity.class &&
                parameterType != Result.class;
    }

    @SneakyThrows
    @Override
    public Object beforeBodyWrite(Object body,
                                  @NotNull MethodParameter methodParameter,
                                  @NotNull MediaType mediaType,
                                  @NotNull Class clazz,
                                  @NotNull ServerHttpRequest request,
                                  @NotNull ServerHttpResponse response) {
        //当返回类型是String时，用的是StringHttpMessageConverter转换器，无法转换为Json格式
        if (body instanceof String) {
            HttpHeaders headers = response.getHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            return new ObjectMapper().writeValueAsString(Result.data(body));
        } else if (Objects.isNull(body)) {
            return Result.success();
        }
        return Result.data(body);
    }
}
