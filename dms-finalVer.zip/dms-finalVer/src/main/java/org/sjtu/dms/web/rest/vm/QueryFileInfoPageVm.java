package org.sjtu.dms.web.rest.vm;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.sjtu.dms.shared.model.PagedAndSorted;
import org.sjtu.dms.shared.model.ShouldNormalize;

@Getter
@Setter
public class QueryFileInfoPageVm extends PagedAndSorted implements ShouldNormalize {
    private String fileName;
    private String fileType;

    @Override
    public void normalize() {
        if (StringUtils.isBlank(super.getSort())) {
            super.setSort("createTime desc");
        }
    }
}
