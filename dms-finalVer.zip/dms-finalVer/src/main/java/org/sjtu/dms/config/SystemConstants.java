package org.sjtu.dms.config;

/**
 * 系统常用变量
 */
public interface SystemConstants {
    /**
     * http request header中的token的key
     */
    String TOKEN_HEADER_KEY = "Authorization";

    /**
     * token前缀
     */
    String TOKEN_PREFIX = "Bearer ";

    /**
     * 默认为空消息
     */
    String DEFAULT_NULL_MESSAGE = "无承载数据";

    /**
     * 默认成功消息
     */
    String DEFAULT_SUCCESS_MESSAGE = "操作成功";

    /**
     * 默认失败消息
     */
    String DEFAULT_FAILURE_MESSAGE = "操作失败";

    /**
     * ADMIN用户
     */
    public static final String ADMIN_USER = "admin";

    /**
     * ADMIN角色
     */
    public static final String ADMIN_ROLE = "admin";

    /**
     * Sort分隔符
     */
    public static final String SORT_SEPARATOR = " ";

    /**
     * RabbitMQ中上传文件的Queue
     */
    public static final String UPLOAD_FILE_QUEUE_NAME = "uploadQueue";
    /**
     * RabbitMQ中上传文件的Exchange
     */
    public static final String UPLOAD_FILE_EXCHANGE_NAME = "amq.direct";
    /**
     * RabbitMQ中上传文件的routingKey
     */
    public static final String UPLOAD_FILE_ROUTING_KEY = "uploadRouting";
}
