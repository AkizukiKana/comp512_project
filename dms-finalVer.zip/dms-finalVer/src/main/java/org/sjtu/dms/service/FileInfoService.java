package org.sjtu.dms.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.compress.utils.FileNameUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.sjtu.dms.config.SystemConstants;
import org.sjtu.dms.config.UserInfoContext;
import org.sjtu.dms.domain.FileInfo;
import org.sjtu.dms.repository.FileInfoRepository;
import org.sjtu.dms.service.dto.FileInfoDto;
import org.sjtu.dms.utils.MinIoUtils;
import org.sjtu.dms.utils.RedisUtils;
import org.sjtu.dms.web.rest.vm.QueryFileInfoPageVm;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
public class FileInfoService {
    private final FileInfoRepository fileInfoRepository;
    private final MinIoUtils minIoUtils;
    private final RedisUtils redisUtils;
    private final RabbitTemplate rabbitTemplate;

    public FileInfoService(FileInfoRepository fileInfoRepository, MinIoUtils minIoUtils, RedisUtils redisUtils, RabbitTemplate rabbitTemplate) {
        this.fileInfoRepository = fileInfoRepository;
        this.minIoUtils = minIoUtils;
        this.redisUtils = redisUtils;
        this.rabbitTemplate = rabbitTemplate;
    }

    public Page<FileInfoDto> getFileInfoPage(QueryFileInfoPageVm param) {
        Specification<FileInfo> spec = (root, query, build) -> {
            List<Predicate> predicateList = new ArrayList<>();
            predicateList.add(build.equal(root.get("createUserId"), UserInfoContext.getCurrentUserId()));
            if (StringUtils.isNotBlank(param.getFileName())) {
                predicateList.add(build.like(root.get("fileName"), String.format("%%%s%%", param.getFileName())));
            }
            if (StringUtils.isNotBlank(param.getFileType())) {
                predicateList.add(build.like(root.get("fileType"), String.format("%%%s%%", param.getFileType())));
            }
            return query.where(predicateList.toArray(new Predicate[0])).getRestriction();
        };
        return fileInfoRepository.findAll(spec, param.buildPageable()).map(FileInfoDto::new);
    }

    public void upload(List<MultipartFile> files) {
        if (CollectionUtils.isNotEmpty(files)) {
            files.forEach(file -> {
                String key = String.valueOf(UUID.randomUUID());
                try {
                    String originalFilename = file.getOriginalFilename();
                    // 将文件暂存到Redis中，并发送保存请求到mq，Redis缓存30分钟，超时文件将被删除
                    redisUtils.set(key, new ObjectMapper().convertValue(file.getBytes(), String.class), 1800);
                    FileInfo fileInfo = new FileInfo();
                    fileInfo.setFilePath(key);
                    fileInfo.setBucketName(minIoUtils.getBucketName());
                    fileInfo.setFileName(originalFilename);
                    fileInfo.setFileType(FileNameUtils.getExtension(originalFilename));
                    fileInfo.setFileByteSize(file.getSize());
                    fileInfo.setSharedFlag(false);
                    fileInfo.setUploadTime(LocalDateTime.now());
                    fileInfo.setCreateUserId(UserInfoContext.getCurrentUserId());
                    // 将消息携带绑定键值：DirectRouting 发送到交换机DirectExchange
                    rabbitTemplate.convertAndSend(SystemConstants.UPLOAD_FILE_EXCHANGE_NAME, SystemConstants.UPLOAD_FILE_ROUTING_KEY, fileInfo);
                } catch (IOException ignore) {
                }
            });
        }
    }

    public void download(Long fileInfoId, HttpServletResponse response) {
        FileInfo fileInfo = fileInfoRepository.findById(fileInfoId).orElseThrow(() -> new RuntimeException("文件信息有误,请重新选择"));
        Long currentUserId = UserInfoContext.getCurrentUserId();
        Boolean sharedFlag = fileInfo.getSharedFlag();
        if (BooleanUtils.isNotTrue(sharedFlag) && !Objects.equals(currentUserId, fileInfo.getCreateUserId())) {
            throw new RuntimeException("文件信息有误");
        }
        minIoUtils.download(fileInfo.getBucketName(), fileInfo.getFilePath(), fileInfo.getFileName(), response);
    }

    public void openShare(Long fileInfoId) {
        FileInfo fileInfo = fileInfoRepository.findById(fileInfoId).orElseThrow(() -> new RuntimeException("文件信息有误,请重新选择"));
        Long currentUserId = UserInfoContext.getCurrentUserId();
        if (null == currentUserId || !currentUserId.equals(fileInfo.getCreateUserId())) {
            throw new RuntimeException("只能操作本人文件");
        }
        fileInfo.setSharedFlag(true);
        fileInfoRepository.save(fileInfo);
    }

    public void closeShare(Long fileInfoId) {
        FileInfo fileInfo = fileInfoRepository.findById(fileInfoId).orElseThrow(() -> new RuntimeException("文件信息有误,请重新选择"));
        Long currentUserId = UserInfoContext.getCurrentUserId();
        if (null == currentUserId || !currentUserId.equals(fileInfo.getCreateUserId())) {
            throw new RuntimeException("只能共享本人文件");
        }
        fileInfo.setSharedFlag(false);
        fileInfoRepository.save(fileInfo);
    }

    public Page<FileInfoDto> getSharePage(QueryFileInfoPageVm param) {
        Specification<FileInfo> spec = (root, query, build) -> {
            List<Predicate> predicateList = new ArrayList<>();
            predicateList.add(build.notEqual(root.get("createUserId"), UserInfoContext.getCurrentUserId()));
            predicateList.add(build.equal(root.get("sharedFlag"), true));
            if (StringUtils.isNotBlank(param.getFileName())) {
                predicateList.add(build.like(root.get("fileName"), String.format("%%%s%%", param.getFileName())));
            }
            if (StringUtils.isNotBlank(param.getFileType())) {
                predicateList.add(build.like(root.get("fileType"), String.format("%%%s%%", param.getFileType())));
            }
            return query.where(predicateList.toArray(new Predicate[0])).getRestriction();
        };
        return fileInfoRepository.findAll(spec, param.buildPageable()).map(FileInfoDto::new);
    }

    public void remove(Long fileInfoId) {
        FileInfo fileInfo = fileInfoRepository.findById(fileInfoId).orElseThrow(() -> new RuntimeException("文件信息有误,请重新选择"));
        boolean removeResult = minIoUtils.remove(fileInfo.getFileName());
        if(!removeResult){
           throw new RuntimeException("删除文件失败");
        }
        fileInfoRepository.deleteById(fileInfo.getId());
    }
}
