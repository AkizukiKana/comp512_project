package org.sjtu.dms.config.permisson;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.sjtu.dms.shared.model.Result;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.List;

/**
 * aop实现权限验证
 */
@Aspect
@Component
@Order(1)
public class PermissionAdvice {
    /**
     * 定义切入点   切入点就PermissionAnnotation注解标注的地方
     */
    @Pointcut("@annotation(org.sjtu.dms.config.permisson.PermissionAnnotation)")
    public void permissionPoint() {
    }

    /**
     * 环绕
     */
    @Around("permissionPoint()")
    public Object hasPermission(ProceedingJoinPoint joinPoint) throws Throwable {
        //方法签名
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        //获取方法
        Method method = methodSignature.getMethod();
        //获取 @PermissionAnnotation 的值
        PermissionAnnotation annotation = method.getAnnotation(PermissionAnnotation.class);
        // 未捕获到注解，放行
        if (null == annotation) {
            return joinPoint.proceed();
        }
        String permission = annotation.value();
        //权限集合
        List<String> currentPermissionList = UserPermissionContext.get();
        //如果权限集合包含 @Permissions 的值
        if (currentPermissionList.contains(permission)) {
            //允许通过，表调用的方法可以往下运行
            return joinPoint.proceed();
        } else {
            // 下面两种选一种
            // throw new PermissionException("权限不足");//HTTPStatus == 403
            // new Result<>(403, null, "权限不足");//HTTPStatus == 200
            return new Result<>(403, null, "权限不足");
        }
    }
}

