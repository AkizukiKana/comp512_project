package org.sjtu.dms.web.rest.vm;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
public class UpdateRoleVm {
    @NotNull
    private Long id;
    @NotBlank
    private String displayName;
    @NotNull
    private List<String> permissionList;
}
