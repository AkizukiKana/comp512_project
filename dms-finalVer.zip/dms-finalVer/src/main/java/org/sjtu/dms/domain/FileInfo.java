package org.sjtu.dms.domain;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "t_sys_fileInfo")
public class FileInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private Long id;
    /**
     * 文件原始名
     */
    private String fileName;
    /**
     * 文件类型
     */
    private String fileType;
    /**
     * 所属桶
     */
    private String bucketName;
    /**
     * 文件所在路径
     */
    private String filePath;
    /**
     * 文件大小
     */
    private Long fileByteSize;
    /**
     * 是否共享
     */
    private Boolean sharedFlag;
    /**
     * 上传人
     */
    private Long createUserId;
    /**
     * 上传时间
     */
    private LocalDateTime uploadTime;
    /**
     * 上传成功时间
     */
    @CreatedDate
    private LocalDateTime createTime;
}
