package org.sjtu.dms.web.rest;

import org.sjtu.dms.config.permisson.PermissionAnnotation;
import org.sjtu.dms.config.permisson.PermissionConstants;
import org.sjtu.dms.service.UserService;
import org.sjtu.dms.service.dto.UserDto;
import org.sjtu.dms.service.dto.UserEditDto;
import org.sjtu.dms.shared.model.PageResult;
import org.sjtu.dms.web.rest.vm.CreateUserVm;
import org.sjtu.dms.web.rest.vm.QueryUserPageVm;
import org.sjtu.dms.web.rest.vm.UpdateUserVm;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/user")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/create")
    @PermissionAnnotation(PermissionConstants.ADMIN)
    public void create(@RequestBody @Valid CreateUserVm param) {
        userService.create(param);
    }

    @GetMapping("/page")
    public PageResult<UserDto> getUserPage(QueryUserPageVm param) {
        return PageResult.create(userService.getUserPage(param));
    }

    @PostMapping("/update")
    @PermissionAnnotation(PermissionConstants.ADMIN)
    public void update(@RequestBody @Valid UpdateUserVm param) {
        userService.update(param);
    }

    @DeleteMapping("/delete")
    @PermissionAnnotation(PermissionConstants.ADMIN)
    public void delete(@RequestParam Long id) {
        userService.delete(id);
    }

    @GetMapping("/edit")
    @PermissionAnnotation(PermissionConstants.ADMIN)
    public UserEditDto getUserEdit(@RequestParam Long id) {
        return userService.getUserEdit(id);
    }
}
