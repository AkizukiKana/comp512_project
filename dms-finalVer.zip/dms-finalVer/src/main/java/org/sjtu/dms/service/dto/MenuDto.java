package org.sjtu.dms.service.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class MenuDto {
    private Long id;
    private String name;
    private String path;
    private String icon;
    private Integer listOrder;
    private Boolean hideInMenu;
    private Long parentId;
    private List<MenuDto> routes;

    public MenuDto() {
    }

    public MenuDto(String name, String path, String icon, Integer listOrder, Boolean hideInMenu, List<MenuDto> childrenMenu) {
        this.name = name;
        this.path = path;
        this.icon = icon;
        this.listOrder = listOrder;
        this.hideInMenu = hideInMenu;
        this.routes = childrenMenu;
    }

    public MenuDto(Long id, String name, String path, String icon, Integer listOrder, Boolean hideInMenu, Long parentId, List<MenuDto> childrenMenu) {
        this.id = id;
        this.name = name;
        this.path = path;
        this.icon = icon;
        this.listOrder = listOrder;
        this.hideInMenu = hideInMenu;
        this.parentId = parentId;
        this.routes = childrenMenu;
    }
}
