package org.sjtu.dms.service;

import org.sjtu.dms.config.permisson.PermissionConstants;
import org.sjtu.dms.service.dto.OptionsDto;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class PermissionService {

    public List<OptionsDto<String>> getPermissionOptions() {
        Map<String, String> permissionMap = PermissionConstants.PERMISSION_MAP;

        List<OptionsDto<String>> result = new ArrayList<>();
        permissionMap.forEach((key, value) -> {
            OptionsDto<String> item = new OptionsDto<>();
            item.setValue(key);
            item.setLabel(value);
            result.add(item);
        });
        return result;
    }
}
