package org.sjtu.dms.web.rest;

import org.sjtu.dms.config.permisson.PermissionAnnotation;
import org.sjtu.dms.config.permisson.PermissionConstants;
import org.sjtu.dms.service.RoleService;
import org.sjtu.dms.service.dto.OptionsDto;
import org.sjtu.dms.service.dto.RoleDto;
import org.sjtu.dms.service.dto.RoleEditDto;
import org.sjtu.dms.shared.model.ListResult;
import org.sjtu.dms.shared.model.PageResult;
import org.sjtu.dms.web.rest.vm.CreateRoleVm;
import org.sjtu.dms.web.rest.vm.QueryRolePageVm;
import org.sjtu.dms.web.rest.vm.UpdateRoleVm;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/role")
public class RoleController {
    private final RoleService roleService;

    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @PostMapping("/create")
    @PermissionAnnotation(PermissionConstants.ADMIN)
    public void create(@RequestBody @Valid CreateRoleVm param) {
        roleService.create(param);
    }

    @GetMapping("/page")
    public PageResult<RoleDto> getRolePage(QueryRolePageVm param) {
        return PageResult.create(roleService.getRolePage(param));
    }

    @PostMapping("/update")
    @PermissionAnnotation(PermissionConstants.ADMIN)
    public void update(@RequestBody @Valid UpdateRoleVm param) {
        roleService.update(param);
    }

    @DeleteMapping("/delete")
    @PermissionAnnotation(PermissionConstants.ADMIN)
    public void delete(@RequestParam Long id) {
        roleService.delete(id);
    }

    @GetMapping("/options")
    public ListResult<OptionsDto<String>> getRoleOptions() {
        return ListResult.create(roleService.getRoleOptions());
    }

    @GetMapping("/edit")
    public RoleEditDto getRoleEdit(@RequestParam Long id) {
        return roleService.getRoleEdit(id);
    }
}
