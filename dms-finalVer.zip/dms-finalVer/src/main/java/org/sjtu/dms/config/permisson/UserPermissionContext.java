package org.sjtu.dms.config.permisson;

import java.util.List;

/**
 * 当前登录用户的权限集
 */
public class UserPermissionContext {
    private static final ThreadLocal<List<String>> CURRENT_USER_PERMISSION = new ThreadLocal<>();

    public static void set(List<String> permissionList) {
        CURRENT_USER_PERMISSION.set(permissionList);
    }

    public static List<String> get() {
        return CURRENT_USER_PERMISSION.get();
    }

    public static void remove() {
        CURRENT_USER_PERMISSION.remove();
    }
}
