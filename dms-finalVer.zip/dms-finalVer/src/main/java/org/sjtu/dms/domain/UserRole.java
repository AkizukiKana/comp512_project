package org.sjtu.dms.domain;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import javax.persistence.*;

/**
 * @author WHW 2020-12
 */
@Getter
@Setter
@Entity
@Table(name = "t_sys_user_roles")
public class UserRole {
    private static final long serialVersionUID = 4390085859787751823L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private Long id;

    private Long roleId;

    private Long userId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId", foreignKey = @ForeignKey(name = "none"), insertable = false, updatable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "roleId", foreignKey = @ForeignKey(name = "none"), insertable = false, updatable = false)
    private Role role;
}
