package org.sjtu.dms.web.rest;

import org.sjtu.dms.service.PermissionService;
import org.sjtu.dms.service.dto.OptionsDto;
import org.sjtu.dms.shared.model.ListResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/permission")
public class PermissionController {
    private final PermissionService permissionService;

    public PermissionController(PermissionService permissionService) {
        this.permissionService = permissionService;
    }

    @GetMapping("/options")
    public ListResult<OptionsDto<String>> getPermissionOptions() {
        return ListResult.create(permissionService.getPermissionOptions());
    }
}
