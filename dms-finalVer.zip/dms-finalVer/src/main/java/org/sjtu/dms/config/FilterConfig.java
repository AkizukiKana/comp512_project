package org.sjtu.dms.config;

import org.sjtu.dms.filter.JwtFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;

/**
 * 拦截器配置
 */
@Configuration
public class FilterConfig {
    @Bean
    public FilterRegistrationBean jwtFilterBean() {
        FilterRegistrationBean<JwtFilter> filterBean = new FilterRegistrationBean<>();
        filterBean.setFilter(new JwtFilter());
        filterBean.setUrlPatterns(Collections.singletonList("/api/*"));
        return filterBean;
    }
}
