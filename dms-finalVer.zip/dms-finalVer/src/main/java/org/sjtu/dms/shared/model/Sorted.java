package org.sjtu.dms.shared.model;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.sjtu.dms.config.SystemConstants;
import org.springframework.data.domain.Sort;

import java.io.Serializable;
import java.util.Arrays;
import java.util.stream.Collectors;

@Getter
@Setter
public class Sorted implements Serializable {
    private static final long serialVersionUID = 337756654407205451L;
    protected String sort;

    public Sort buildSort() {
        if (this instanceof ShouldNormalize) {
            ((ShouldNormalize) this).normalize();
        }
        if (StringUtils.isBlank(sort)) {
            return Sort.unsorted();
        }
        String[] sortArray = sort.trim().split(",");
        return Sort.by(Arrays.stream(sortArray).filter(StringUtils::isNotBlank).distinct().map(sort -> {
            String[] sortFieldArray = sort.split(SystemConstants.SORT_SEPARATOR);
            if (sortFieldArray.length >= 2) {
                return new Sort.Order(Sort.Direction.fromString(sortFieldArray[1]), sortFieldArray[0]);
            }
            return new Sort.Order(Sort.Direction.ASC, sortFieldArray[0]);
        }).collect(Collectors.toList()));
    }

    public Sort buildSort(String defaultSort, boolean alwaysDefault) {
        if (StringUtils.isBlank(sort)) {
            sort = defaultSort;
        } else if (alwaysDefault) {
            sort = defaultSort + "," + sort;
        }
        return buildSort();
    }
}
