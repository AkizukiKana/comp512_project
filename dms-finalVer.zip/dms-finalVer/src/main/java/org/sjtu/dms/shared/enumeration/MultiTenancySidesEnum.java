package org.sjtu.dms.shared.enumeration;

import com.fasterxml.jackson.annotation.JsonValue;

public enum MultiTenancySidesEnum {
    //租户
    TENANT(1),
    //宿主
    HOST(2);

    private final Integer id;

    MultiTenancySidesEnum(Integer id) {
        this.id = id;
    }

    @JsonValue
    public Integer getId() {
        return id;
    }
}
