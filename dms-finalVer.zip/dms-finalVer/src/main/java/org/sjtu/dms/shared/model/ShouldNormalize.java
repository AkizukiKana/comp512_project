package org.sjtu.dms.shared.model;

public interface ShouldNormalize {
    void normalize();
}
