package org.sjtu.dms.service;

import org.sjtu.dms.domain.Permission;
import org.sjtu.dms.domain.User;
import org.sjtu.dms.domain.UserRole;
import org.sjtu.dms.repository.PermissionRepository;
import org.sjtu.dms.repository.UserRepository;
import org.sjtu.dms.repository.UserRoleRepository;
import org.sjtu.dms.service.dto.LogInDto;
import org.sjtu.dms.service.dto.MenuDto;
import org.sjtu.dms.utils.JwtUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final PermissionRepository permissionRepository;
    private final UserRoleRepository userRoleRepository;

    public AuthService(UserRepository userRepository,
                       PermissionRepository permissionRepository,
                       UserRoleRepository userRoleRepository) {
        this.userRepository = userRepository;
        this.permissionRepository = permissionRepository;
        this.userRoleRepository = userRoleRepository;
    }

    /**
     * 获取token
     */
    public String authorise(String userName, String password, boolean rememberMe) {
        // 验证用户
        User user = userRepository.findByUserNameAndPassword(userName, password).orElseThrow(() -> new RuntimeException("账号或密码错误"));
        // 获取权限
        List<UserRole> userRoleList = userRoleRepository.findByUserId(user.getId());
        List<Long> roleIdList = userRoleList.stream().map(UserRole::getRoleId).distinct().collect(Collectors.toList());
        List<Permission> permissionList = permissionRepository.findByRoleIdIn(roleIdList);
        return JwtUtils.createToken(userName, user.getId(), rememberMe, permissionList.stream().map(Permission::getName).distinct().collect(Collectors.toList()));
    }

    /**
     * Login
     */
    public LogInDto login(String userName, String password, boolean rememberMe) {
        String token = authorise(userName, password, rememberMe);
        List<String> permissions = JwtUtils.getPermissions(token);

        Long userId = Long.parseLong(JwtUtils.getUserId(token));
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("账号或密码错误"));

        List<MenuDto> menus1 = new ArrayList<>();
        menus1.add(new MenuDto("File List", "file/fileList", "", 1, false, null));
        menus1.add(new MenuDto("Shared File", "file/sharedFile", "", 2, false, null));

        List<MenuDto> menus2 = new ArrayList<>();
        menus2.add(new MenuDto("User", "system/user", "", 1, false, null));
        menus2.add(new MenuDto("Role", "system/role", "", 2, false, null));

        List<MenuDto> menus = new ArrayList<>();
        menus.add(new MenuDto("File Management", "", "", 1, false, menus1));
        menus.add(new MenuDto("System Management", "", "", 2, false, menus2));

        return new LogInDto(userName, user.getName(), token, permissions, menus);
    }
}