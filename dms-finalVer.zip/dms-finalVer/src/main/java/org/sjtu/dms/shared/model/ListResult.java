package org.sjtu.dms.shared.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListResult<T> {
    /**
     * 总条数
     */
    private final long total;
    /**
     * 具体内容
     */
    private final List<T> items;

    public ListResult(long total, List<T> items) {
        this.total = total;
        this.items = items;
    }

    public static <T> ListResult<T> create(List<T> list) {
        if (CollectionUtils.isNotEmpty(list)) {
            return new ListResult<>(list.size(), Collections.unmodifiableList(list));
        } else {
            return new ListResult<>(0, new ArrayList<>());
        }
    }
}
