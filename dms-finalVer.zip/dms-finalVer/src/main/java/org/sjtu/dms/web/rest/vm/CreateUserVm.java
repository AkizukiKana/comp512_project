package org.sjtu.dms.web.rest.vm;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
public class CreateUserVm {
    @NotBlank
    private String userName;
    @NotBlank
    private String password;
    @NotBlank
    private String name;
    @NotBlank
    private String emailAddress;
    private String phoneNumber;
    @NotNull
    private List<String> assignedRoleNameList;
}
