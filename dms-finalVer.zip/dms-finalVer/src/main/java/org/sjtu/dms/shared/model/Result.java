package org.sjtu.dms.shared.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.sjtu.dms.config.SystemConstants;
import org.sjtu.dms.shared.enumeration.SystemResultCodeEnum;

import javax.servlet.http.HttpServletResponse;
import java.io.Serializable;

/**
 * Rest接口统一返回结果包装类
 *
 * @author zhanghua
 * @since 2022/3/15
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class Result<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 状态码
     */
    private int code;
    /**
     * 是否成功
     */
    private boolean success;
    /**
     * 承载数据
     */
    private T data;
    /**
     * 返回消息
     */
    private String msg;
    /**
     * 物料错误结果
     */
    private String errorResult;

    public Result(int code, T data, String msg) {
        this.code = code;
        this.data = data;
        this.msg = msg;
        this.success = SystemResultCodeEnum.SUCCESS.code == code;
    }

    /**
     * 返回Result
     *
     * @param data 数据
     * @param <T>  T 泛型标记
     * @return Result
     */
    public static <T> Result<T> data(T data) {
        return data(data, SystemConstants.DEFAULT_SUCCESS_MESSAGE);
    }

    /**
     * 返回Result
     *
     * @param data 数据
     * @param msg  消息
     * @param <T>  T 泛型标记
     * @return Result
     */
    public static <T> Result<T> data(T data, String msg) {
        return data(HttpServletResponse.SC_OK, data, msg);
    }

    /**
     * 返回Result
     *
     * @param code 状态码
     * @param data 数据
     * @param msg  消息
     * @param <T>  T 泛型标记
     * @return Result
     */
    public static <T> Result<T> data(int code, T data, String msg) {
        return new Result<>(code, data, data == null ? SystemConstants.DEFAULT_NULL_MESSAGE : msg);
    }

    public static <T> Result<T> success() {
        return new Result<>(HttpServletResponse.SC_OK, null, SystemConstants.DEFAULT_SUCCESS_MESSAGE);
    }
}
