package org.sjtu.dms.service;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.sjtu.dms.config.SystemConstants;
import org.sjtu.dms.config.permisson.PermissionConstants;
import org.sjtu.dms.domain.Permission;
import org.sjtu.dms.domain.Role;
import org.sjtu.dms.repository.PermissionRepository;
import org.sjtu.dms.repository.RoleRepository;
import org.sjtu.dms.service.dto.OptionsDto;
import org.sjtu.dms.service.dto.RoleDto;
import org.sjtu.dms.service.dto.RoleEditDto;
import org.sjtu.dms.web.rest.vm.CreateRoleVm;
import org.sjtu.dms.web.rest.vm.QueryRolePageVm;
import org.sjtu.dms.web.rest.vm.UpdateRoleVm;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RoleService {
    private final RoleRepository roleRepository;
    private final PermissionRepository permissionRepository;

    public RoleService(RoleRepository roleRepository,
                       PermissionRepository permissionRepository) {
        this.roleRepository = roleRepository;
        this.permissionRepository = permissionRepository;
    }

    public void create(CreateRoleVm param) {
        Optional<Role> existRole = roleRepository.findByName(param.getName());
        if (existRole.isPresent()) {
            throw new RuntimeException(String.format("用户%s已存在", param.getName()));
        }
        Role role = new Role();
        role.setName(param.getName());
        role.setDisplayName(param.getDisplayName());
        role = roleRepository.save(role);

        // 权限
        List<String> paramPermissionList = param.getPermissionList();
        if (CollectionUtils.isNotEmpty(paramPermissionList)) {
            Role finalRole = role;
            List<Permission> createPermissionList = paramPermissionList.stream().map(s -> {
                Permission data = new Permission();
                data.setName(s);
                data.setRoleId(finalRole.getId());
                return data;
            }).collect(Collectors.toList());
            permissionRepository.saveAll(createPermissionList);
        }
    }

    public Page<RoleDto> getRolePage(QueryRolePageVm param) {
        Specification<Role> spec = (root, query, builder) -> {
            List<Predicate> predicateList = new ArrayList<>();
            if (StringUtils.isNotBlank(param.getFilter())) {
                predicateList.add(builder.or(
                        builder.like(root.get("name"), String.format("%%%s%%", param.getFilter())),
                        builder.like(root.get("displayName"), String.format("%%%s%%", param.getFilter()))));
            }
            return builder.and(predicateList.toArray(new Predicate[0]));
        };
        Page<Role> rolePage = roleRepository.findAll(spec, param.buildPageable());
        return rolePage.map(s -> {
            RoleDto dto = new RoleDto();
            dto.setId(s.getId());
            dto.setName(s.getName());
            dto.setDisplayName(s.getDisplayName());
            return dto;
        });
    }

    public void update(UpdateRoleVm param) {
        Role role = roleRepository.findById(param.getId()).orElseThrow(() -> new RuntimeException("角色不存在"));
        List<String> paramPermissionList = param.getPermissionList();
        if (Objects.equals(role.getName(), SystemConstants.ADMIN_ROLE) &&
                !paramPermissionList.contains(PermissionConstants.ADMIN)) {
            throw new RuntimeException("管理员权限不能从管理员角色中删除");
        }
        role.setDisplayName(param.getDisplayName());
        roleRepository.save(role);

        // 删除权限
        List<Permission> permissionList = permissionRepository.findByRoleId(param.getId());
        List<Permission> deletePermissionList = permissionList.stream().map(s -> {
            if (paramPermissionList.contains(s.getName())) {
                paramPermissionList.remove(s.getName());
                return null;
            } else {
                return s;
            }
        }).filter(Objects::nonNull).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(deletePermissionList)) {
            permissionRepository.deleteAll(deletePermissionList);
        }
        // 新增权限
        if (CollectionUtils.isNotEmpty(paramPermissionList)) {
            List<Permission> createPermissionList = paramPermissionList.stream().map(s -> {
                Permission data = new Permission();
                data.setName(s);
                data.setRoleId(param.getId());
                return data;
            }).collect(Collectors.toList());
            permissionRepository.saveAll(createPermissionList);
        }
    }

    public void delete(Long id) {
        Optional<Role> roleOptional = roleRepository.findById(id);
        if (!roleOptional.isPresent()) {
            return;
        }
        Role role = roleOptional.get();
        if (SystemConstants.ADMIN_ROLE.equalsIgnoreCase(role.getName())) {
            throw new RuntimeException("不能删除管理员角色");
        }
        roleRepository.deleteById(id);
    }

    public List<OptionsDto<String>> getRoleOptions() {
        List<Role> roleList = roleRepository.findAll();
        return roleList.stream().map(s -> new OptionsDto<>(s.getDisplayName(), s.getName())).collect(Collectors.toList());
    }

    public RoleEditDto getRoleEdit(Long id) {
        Optional<Role> roleOptional = roleRepository.findById(id);
        if (!roleOptional.isPresent()) {
            throw new RuntimeException("角色不存在");
        }
        Role role = roleOptional.get();
        List<Permission> permissionList = permissionRepository.findByRoleId(id);

        RoleEditDto result = new RoleEditDto();
        result.setId(role.getId());
        result.setName(role.getName());
        result.setDisplayName(role.getDisplayName());
        result.setPermissionList(permissionList.stream().map(Permission::getName).collect(Collectors.toList()));

        return result;
    }
}
