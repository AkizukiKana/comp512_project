package org.sjtu.dms.config;

/**
 * 当前登录用户的信息
 */
public class UserInfoContext {
    private static final ThreadLocal<Long> CURRENT_USER_ID = new ThreadLocal<>();
    private static final ThreadLocal<String> CURRENT_USER_NAME = new ThreadLocal<>();

    public static void setCurrentUserId(Long id) {
        CURRENT_USER_ID.set(id);
    }

    public static Long getCurrentUserId() {
        return CURRENT_USER_ID.get();
    }

    public static void setCurrentUserName(String userName) {
        CURRENT_USER_NAME.set(userName);
    }

    public static String getCurrentUserName() {
        return CURRENT_USER_NAME.get();
    }

    public static void remove() {
        CURRENT_USER_ID.remove();
        CURRENT_USER_NAME.remove();
    }
}
