package org.sjtu.dms.config;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMq配置
 */
@Slf4j
@Configuration
public class UploadRabbitConfig {
    /**
     * 队列 directQueue
     */
    @Bean
    public Queue queue() {
        return new Queue(SystemConstants.UPLOAD_FILE_QUEUE_NAME, true, false, false);
    }

    /**
     * Direct交换机 directExchange
     */
    @Bean
    public DirectExchange exchange() {
        return new DirectExchange(SystemConstants.UPLOAD_FILE_EXCHANGE_NAME, true, false);
    }

    /**
     * 绑定 将队列和交换机绑定, 并设置用于匹配键：directRouting
     */
    @Bean
    public Binding bindingDirect() {
        return BindingBuilder.bind(queue()).to(exchange()).with(SystemConstants.UPLOAD_FILE_ROUTING_KEY);
    }

    /**
     * 针对不同的消费者，可以进行不同的容器配置，来实现多个消费者应用不同的配置。
     */
    @Bean(name = "singleListenerContainer")
    public SimpleRabbitListenerContainerFactory listenerContainer(ConnectionFactory connectionFactory) {
        // 定义消息监听器所在的容器工厂
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        // 设置容器工厂所用的实例
        factory.setConnectionFactory(connectionFactory);
        // 设置消息在传输中的格式，在这里采用JSON的格式进行传输
        // factory.setMessageConverter(new Jackson2JsonMessageConverter());
        // 设置并发消费者实例的初始数量
        factory.setConcurrentConsumers(3);
        // 设置并发消费者实例的最大数量
        factory.setMaxConcurrentConsumers(3);
        // 设置并发消费者实例中每个实例拉取的消息数量-在这里为1个
        factory.setPrefetchCount(2);
        // 关闭自动应答
        // 设置不公平分发，更改为每次读取1条消息,在消费者未回执确认之前,不在进行下一条消息的投送，而不是默认的轮询；
        // 也就是说，我处理完了，我再接受下一次的投递，属于消费者端的控制
        // 不设置的话，就是采用轮询的方法去监听队列，你一条我一条
        factory.setAcknowledgeMode(AcknowledgeMode.MANUAL);
        factory.setConsumerBatchEnabled(true);
        factory.setBatchListener(true);
        factory.setBatchSize(4);
        return factory;
    }

    /**
     * 默认实现就是SimpleMessageConverter,基于JDK的ObjectOutputStream完成序列化
     * SimpleMessageConverter.createMessage(){SerializationUtils.serialize(object);}
     */
    @Bean
    public MessageConverter jsonMessageConverter() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper.registerModules(new JavaTimeModule());
        return new Jackson2JsonMessageConverter(objectMapper);
    }
}
