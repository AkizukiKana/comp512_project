package org.sjtu.dms.service.dto;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class OptionsDto<T> {
    private String label;
    private T value;
}
