package org.sjtu.dms.config.permisson;

import java.util.HashMap;
import java.util.Map;

/**
 * 权限
 */
public class PermissionConstants {
    public static final String ADMIN = "admin";
    public static final String USER = "user";
    public static final String TEST = "test";
    public static final Map<String, String> PERMISSION_MAP = new HashMap<>();

    static {
        PERMISSION_MAP.put(PermissionConstants.ADMIN, "admin");
        PERMISSION_MAP.put(PermissionConstants.USER, "user");
        PERMISSION_MAP.put(PermissionConstants.TEST, "test");
    }
}
