package org.sjtu.dms.shared.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermissionException extends RuntimeException {
    private static final long serialVersionUID = -4279156189842621247L;

    public PermissionException() {
    }

    public PermissionException(String message) {
        super(message);
    }
}
