package org.sjtu.dms.service.dto;

import lombok.*;
import org.sjtu.dms.domain.FileInfo;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class FileInfoDto {
    private Long id;
    /**
     * 文件原始名
     */
    private String fileName;
    /**
     * 文件类型
     */
    private String fileType;
    /**
     * 文件大小
     */
    private Long fileByteSize;
    /**
     * 上传时间
     */
    private LocalDateTime createTime;
    /**
     * 是否共享
     */
    private Boolean sharedFlag;

    public FileInfoDto(FileInfo entity) {
        this.id = entity.getId();
        this.fileName = entity.getFileName();
        this.fileType = entity.getFileType();
        this.fileByteSize = entity.getFileByteSize();
        this.createTime = entity.getCreateTime();
        this.sharedFlag = entity.getSharedFlag();
    }
}
