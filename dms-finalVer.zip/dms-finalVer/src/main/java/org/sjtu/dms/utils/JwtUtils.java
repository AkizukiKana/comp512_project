package org.sjtu.dms.utils;

import io.jsonwebtoken.*;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * jwt工具类
 */
public class JwtUtils {
    public static final String TOKEN_HEADER = "Authorization";
    public static final String TENANT_HEADER = "Tenant";
    public static final String USER_ID_HEADER = "UserId";
    public static final String USER_NAME_HEADER = "UserName";
    public static final String TOKEN_PREFIX = "Bearer ";

    private static final String SECRET = "jwtsecretdemo";
    private static final String ISS = "echisan";

    // 过期时间是3600秒，既是1个小时
    private static final long EXPIRATION = 30 * 24 * 3600L;

    // 选择了记住我之后的过期时间为7天
    private static final long EXPIRATION_REMEMBER = 604800L;

    /**
     * 创建token
     */
    public static String createToken(String userName, Long userId, boolean isRememberMe, List<String> permissions) {
        long expiration = isRememberMe ? EXPIRATION_REMEMBER : EXPIRATION;
        HashMap<String, Object> map = new HashMap<>(4);
        //you can put any data in the map
        map.put("userId", userId);
        map.put("permissions", permissions);
        return Jwts.builder()
                .signWith(SignatureAlgorithm.HS512, SECRET)
                .setIssuer(ISS)
                .setClaims(map)
                .setSubject(userName)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration * 1000))
                .compact();
    }


    public static boolean validateToken(String authToken) {
        try {
            Jwts.parser().setSigningKey(SECRET).parseClaimsJws(authToken);
            return true;
        } catch (SecurityException | io.jsonwebtoken.MalformedJwtException e) {
            // this.log.info("Invalid JWT signature.");
        } catch (ExpiredJwtException e) {
            // this.log.info("Expired JWT token.");
        } catch (UnsupportedJwtException e) {
            // this.log.info("Unsupported JWT token.");
        } catch (IllegalArgumentException e) {
            // this.log.info("JWT token compact of handler are invalid.");
        }
        return false;
    }

    /**
     * 从token中获取用户名
     */
    public static String getUserName(String token) {
        return getTokenBody(token).getSubject();
    }

    /**
     * 从token中获取用户id
     */
    public static String getUserId(String token) {
        Object obj = getTokenBody(token).get("userId");
        return String.valueOf(String.valueOf(obj));
    }

    /**
     * 是否已过期
     */
    public static boolean isExpiration(String token) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        System.out.println(sdf.format(getTokenBody(token).getExpiration()));
        return getTokenBody(token).getExpiration().before(new Date());
    }

    private static Claims getTokenBody(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET)
                .parseClaimsJws(token)
                .getBody();
    }

    public static List<String> getPermissions(String token) {
        Object obj = getTokenBody(token).get("permissions");
        List<String> result = new ArrayList<>();
        if (obj instanceof Collection<?>) {
            for (Object o : (Collection<?>) obj) {
                result.add((String) o);
            }
        }
        return result;
    }
}
