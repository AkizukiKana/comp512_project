package org.sjtu.dms.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.sjtu.dms.config.SystemConstants;
import org.sjtu.dms.domain.FileInfo;
import org.sjtu.dms.repository.FileInfoRepository;
import org.sjtu.dms.utils.MinIoUtils;
import org.sjtu.dms.utils.RedisUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class UploadReceiver {
    private final RedisUtils redisUtils;
    private final MinIoUtils minIoUtils;
    private final FileInfoRepository fileInfoRepository;

    public UploadReceiver(RedisUtils redisUtils, MinIoUtils minIoUtils, FileInfoRepository fileInfoRepository) {
        this.redisUtils = redisUtils;
        this.minIoUtils = minIoUtils;
        this.fileInfoRepository = fileInfoRepository;
    }

    @RabbitListener(queues = SystemConstants.UPLOAD_FILE_QUEUE_NAME, containerFactory = "singleListenerContainer")
    public void directQueue(List<Message> mqMessages, @Headers Map<String, Object> headers, Channel channel) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModules(new JavaTimeModule());
        for (Message message : mqMessages) {
            // 解析mq中的消息
            FileInfo fileInfo = null;
            try {
                fileInfo = objectMapper.readValue(message.getBody(), FileInfo.class);
                String redisKey = fileInfo.getFilePath();
                byte[] inputStream = objectMapper.convertValue(redisUtils.get(redisKey), byte[].class);
                if (null != inputStream) {
                    // 当redis中文件流不为空时进行上传
                    String uploadTimeStr = LocalDate.now().toString();
                    if (null != fileInfo.getUploadTime()) {
                        uploadTimeStr = fileInfo.getUploadTime().toLocalDate().toString();
                    }
                    // 上传并保存MinIo中文件路径到数据库
                    String minIoFilePath = minIoUtils.upload(fileInfo.getBucketName(), uploadTimeStr, fileInfo.getFileName(), inputStream);
                    fileInfo.setFilePath(minIoFilePath);
                    fileInfoRepository.save(fileInfo);
                    redisUtils.del(redisKey);
                    // 确认消息；当该参数为 true 时，则可以一次性确认 deliveryTag 小于等于传入值的所有消息
                    channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
                } else {
                    // 拒绝消息；requeue：true业务失败需重新消费；false：丢弃/死信
                    channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
                }
            } catch (Exception e) {
                String messageStr = "";
                try {
                    if (null != fileInfo) {
                        messageStr = objectMapper.writeValueAsString(fileInfo);
                    }
                } catch (Exception ignore) {
                }
                log.error("接收到消息为：{} ，消息异常消费 ： {}", messageStr, e.getMessage());
                try {
                    channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
                } catch (IOException ignore) {
                }
            }
        }
    }
}
