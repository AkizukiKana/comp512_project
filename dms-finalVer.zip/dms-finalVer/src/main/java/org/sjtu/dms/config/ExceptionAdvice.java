package org.sjtu.dms.config;

import org.sjtu.dms.shared.exception.PermissionException;
import org.sjtu.dms.shared.model.Result;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常处理类
 */
@RestControllerAdvice
public class ExceptionAdvice {
    /**
     * 权限异常解析
     */
    @ExceptionHandler(PermissionException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public Result<?> handlePermissionException(PermissionException e) {
        return new Result<>(403, null, e.getMessage());
    }

    /**
     * 运行时异常解析
     */
    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Result<?> handleRuntimeException(RuntimeException e) {
        return new Result<>(500, null, e.getMessage());
    }
}
