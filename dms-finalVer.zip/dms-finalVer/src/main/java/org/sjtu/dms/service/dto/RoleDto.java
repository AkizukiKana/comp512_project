package org.sjtu.dms.service.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class RoleDto {
    private Long id;
    private String name;
    private String displayName;
    private List<String> grantedPermissionList;
}
