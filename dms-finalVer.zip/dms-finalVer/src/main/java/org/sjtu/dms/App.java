package org.sjtu.dms;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import java.net.Inet4Address;
import java.net.UnknownHostException;

/**
 * Application
 */
@SpringBootApplication(scanBasePackages = {"org.sjtu.dms"})
@EnableJpaAuditing
public class App {
    private static final Logger log = LoggerFactory.getLogger(App.class);

    public static void main(String[] args) throws UnknownHostException {
        Environment env = new SpringApplication(App.class).run(args).getEnvironment();
        String protocol = "http";
        if (env.getProperty("server.ssl.key-store") != null) {
            protocol = "https";
        }
        log.info("\n----------------------------------------------------\r\n\t" +
                        "Application '{}' is running! Access URLs:\r\n\t" +
                        "Local: \t{}://localhost:{}\r\n\t" +
                        "External: \t{}://{}:{}\r\n\t" +
                        "Profile(s): \t{}\r\n" +
                        "----------------------------------------------------",
                env.getProperty("spring.application.name"),
                protocol,
                env.getProperty("server.port"),
                protocol,
                Inet4Address.getLocalHost().getHostAddress(),
                env.getProperty("server.port"),
                env.getActiveProfiles()
        );
    }
}
