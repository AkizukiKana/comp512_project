package org.sjtu.dms.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.sjtu.dms.config.SystemConstants;
import org.sjtu.dms.config.UserInfoContext;
import org.sjtu.dms.config.permisson.UserPermissionContext;
import org.sjtu.dms.shared.model.Result;
import org.sjtu.dms.utils.JwtUtils;
import org.springframework.http.MediaType;
import org.springframework.lang.NonNull;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * jwt拦截器
 */
@Slf4j
public class JwtFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain) throws ServletException, IOException {
        UserPermissionContext.remove();
        UserInfoContext.remove();
        // 验证token
        String jwtToken = resolveJwtTokenFromHeader(request);
        if (StringUtils.isNotBlank(jwtToken) && JwtUtils.validateToken(jwtToken)) {
            response.addHeader(SystemConstants.TOKEN_HEADER_KEY, jwtToken);
            // 缓存用户权限
            UserPermissionContext.set(JwtUtils.getPermissions(jwtToken));
            // 缓存用户信息
            UserInfoContext.setCurrentUserId(Long.parseLong(JwtUtils.getUserId(jwtToken)));
            UserInfoContext.setCurrentUserName(JwtUtils.getUserName(jwtToken));
            chain.doFilter(request, response);
        } else {
            // throw new JwtException("请登录");
            ObjectMapper objectMapper = new ObjectMapper();
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
            ServletOutputStream outputStream = response.getOutputStream();
            outputStream.write(objectMapper.writeValueAsBytes(new Result<>(401, null, "请登录")));
            outputStream.close();
        }
    }

    private String resolveJwtTokenFromHeader(final HttpServletRequest request) {
        String bearerToken = request.getHeader(SystemConstants.TOKEN_HEADER_KEY);
        return StringUtils.isNotBlank(bearerToken) && bearerToken.startsWith(SystemConstants.TOKEN_PREFIX) ?
                bearerToken.substring(SystemConstants.TOKEN_PREFIX.length()) :
                bearerToken;
    }
}
