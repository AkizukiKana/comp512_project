package org.sjtu.dms.utils;

import io.minio.*;
import io.minio.http.Method;
import io.minio.messages.Bucket;
import io.minio.messages.Item;
import org.apache.commons.compress.utils.FileNameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.sjtu.dms.config.MinIoProperties;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.activation.MimetypesFileTypeMap;
import javax.annotation.PostConstruct;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.*;

/**
 * Mio工具类
 */
@Component
public class MinIoUtils {
    private final MinIoProperties minIoProperties;
    private final MinioClient minioClient;

    public MinIoUtils(MinIoProperties minIoProperties, MinioClient minioClient) {
        this.minIoProperties = minIoProperties;
        this.minioClient = minioClient;
    }

    @PostConstruct
    public void init() {
        String bucketName = minIoProperties.getBucketName();
        if (!bucketExists(bucketName)) {
            makeBucket(bucketName);
        }
    }

    /**
     * @return 全局默认 Bucket
     */
    public String getBucketName() {
        return minIoProperties.getBucketName();
    }

    /**
     * 查看存储bucket是否存在
     *
     * @return 是否存在
     */
    public Boolean bucketExists(String bucketName) {
        try {
            return minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucketName).build());
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 创建存储bucket
     *
     * @return 是否成功
     */
    public Boolean makeBucket(String bucketName) {
        try {
            minioClient.makeBucket(MakeBucketArgs.builder().bucket(bucketName).build());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 删除存储bucket
     *
     * @return 是否成功
     */
    public Boolean removeBucket(String bucketName) {
        try {
            minioClient.removeBucket(RemoveBucketArgs.builder().bucket(bucketName).build());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 获取全部bucket
     */
    public List<Bucket> getAllBuckets() {
        return getAllBuckets(minIoProperties.getBucketName());
    }

    public List<Bucket> getAllBuckets(String bucketName) {
        try {
            return minioClient.listBuckets();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }


    /**
     * 文件上传
     *
     * @param file 文件
     * @return 文件名
     */
    public String upload(MultipartFile file) {
        return upload(minIoProperties.getBucketName(), file);
    }

    public String upload(String bucketName, MultipartFile file) {
        String originalFilename = file.getOriginalFilename();
        if (StringUtils.isBlank(originalFilename)) {
            throw new RuntimeException("文件解析失败");
        }
        // 构建文件名
        String fileName = UUID.randomUUID() + originalFilename.substring(originalFilename.lastIndexOf("."));
        String dateStr = DateFormatUtils.format(Calendar.getInstance(TimeZone.getTimeZone("UTC")).getTime(), "yyyy-MM-dd");
        String objectName = dateStr + "/" + fileName;
        try {
            PutObjectArgs objectArgs = PutObjectArgs.builder()
                    .bucket(bucketName)
                    .object(objectName)
                    .stream(file.getInputStream(), file.getSize(), -1)
                    .contentType(file.getContentType())
                    .build();
            //文件名称相同会覆盖
            minioClient.putObject(objectArgs);
            return objectName;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 文件上传
     *
     * @param originalFilename 文件
     * @return 文件名
     */
    public String upload(String bucketName, String uploadDate, String originalFilename, byte[] inputStream) {
        String contentType = new MimetypesFileTypeMap().getContentType(originalFilename);
        String extension = FileNameUtils.getExtension(originalFilename);

        ByteArrayInputStream arrayInputStream = new ByteArrayInputStream(inputStream);
        // 构建文件名
        // String dateStr = DateFormatUtils.format(Calendar.getInstance(TimeZone.getTimeZone("UTC")).getTime(), "yyyy-MM-dd");
        String objectName = uploadDate + "/" + UUID.randomUUID() + "." + extension;
        try {
            PutObjectArgs objectArgs = PutObjectArgs.builder()
                    .bucket(bucketName)
                    //文件名称相同会覆盖
                    .object(objectName)
                    .stream(arrayInputStream, arrayInputStream.available(), -1)
                    .contentType(contentType)
                    .build();
            minioClient.putObject(objectArgs);
            return objectName;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 生成一个GET请求的分享链接。
     * 失效时间默认是7天。
     */
    public String preview(String fileName) {
        return preview(minIoProperties.getBucketName(), fileName);
    }

    public String preview(String bucketName, String fileName) {
        // bucketName 存储桶名称    objectName 存储桶里的对象名称  expiry 失效时间（以秒为单位），默认是7天，不得大于七天
        GetPresignedObjectUrlArgs build = GetPresignedObjectUrlArgs.builder()
                .bucket(bucketName)
                .object(fileName)
                .method(Method.GET)
                .expiry(24 * 60 * 60)
                .build();
        try {
            return minioClient.getPresignedObjectUrl(build);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 文件下载
     *
     * @param filePath 文件在MinIo中的全路径
     */
    public void download(String filePath, HttpServletResponse response) {
        download(minIoProperties.getBucketName(), filePath, filePath.substring(filePath.lastIndexOf("/") + 1), response);
    }

    /**
     * @param filePath 文件在MinIo中的全路径
     * @param fileName 下载的文件名
     */
    public void download(String filePath, String fileName, HttpServletResponse response) {
        download(minIoProperties.getBucketName(), filePath, fileName, response);
    }

    public void download(String bucketName, String filePath, String fileName, HttpServletResponse response) {
        GetObjectArgs objectArgs = GetObjectArgs.builder().bucket(bucketName).object(filePath).build();
        try (GetObjectResponse objectResponse = minioClient.getObject(objectArgs)) {
            response.setCharacterEncoding("utf-8");
            // 设置强制下载不打开
            // response.setContentType("application/force-download");
            try {
                response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
            } catch (Exception e) {
                response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
            }
            try (ServletOutputStream outputStream = response.getOutputStream()) {
                StreamUtils.copy(objectResponse, outputStream);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("下载失败");
        }
    }

    /**
     * 查看文件对象
     *
     * @return 存储bucket内文件对象信息
     */
    public List<Item> listObjects() {
        Iterable<Result<Item>> results = minioClient.listObjects(
                ListObjectsArgs.builder().bucket(minIoProperties.getBucketName()).build());
        List<Item> items = new ArrayList<>();
        try {
            for (Result<Item> result : results) {
                items.add(result.get());
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return items;
    }

    /**
     * 删除
     *
     * @param fileName 文件名
     * @return 是否成功
     */
    public boolean remove(String fileName) {
        try {
            minioClient.removeObject(RemoveObjectArgs.builder().bucket(minIoProperties.getBucketName()).object(fileName).build());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
