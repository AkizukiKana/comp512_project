import { Settings as LayoutSettings } from '@ant-design/pro-layout';

const Settings: LayoutSettings & {
  pwa?: boolean;
  logo?: string;
} = {
  navTheme: 'dark',
  //primaryColor: '#1890ff',
  primaryColor: '#099373',
  layout: 'side',
  contentWidth: 'Fluid',
  fixedHeader: false,
  fixSiderbar: true,
  title: 'DMS',
  pwa: false,
  logo: '/logo.png',
  headerHeight: 48,
};

export default Settings;
