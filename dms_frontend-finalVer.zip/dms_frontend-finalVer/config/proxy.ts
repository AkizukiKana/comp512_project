/**
 * The agent cannot take effect in the production environment
 * so there is no configuration of the production environment
 * For details, please see
 * https://pro.ant.design/docs/deploy
 */
export default {
  dev: {
    // http://localhost:8097** -> http://192.168.184.1:8097**
    '/dms': {
      // Proxy target
      target: 'http://localhost:8097',
      // Some functionalities (e.g. cookie) may require origin
      changeOrigin: true,
      // pathRewrite: { '^/dms': '' },
    },
  },
  test: {
    '/api/': {
      target: 'http://smp-prd.sh-ctmc.com',
      changeOrigin: true,
      pathRewrite: { '^/api': '' },
    },
  },
  pre: {
    '/api/': {
      target: 'http://localhost:9527',
      changeOrigin: true,
      pathRewrite: { '^/api': '' },
    },
  },
};
