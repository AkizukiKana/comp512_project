export default [
  {
    path: '/user',
    layout: false,
    routes: [
      {
        path: '/user',
        routes: [{ name: 'login', path: '/user/login', component: './user/Login' }],
      },
      { component: './404' },
    ],
  },
  {
    path: "/file",
    routes: [
      { path: '/file/fileList', component: './file/file-list' },
      { path: '/file/sharedFile', component: './file/shared-file' },
    ],
  },
  {
    path: '/system',
    routes: [
      { path: '/system/user', component: './system/user' },
      { path: '/system/role', component: './system/role' },
    ],
  },
  { path: '/welcome', icon: 'smile', component: './Welcome' },
  { path: '/', redirect: '/welcome' },
  { component: './404' },
];
