import { notification } from 'antd';

const codeMessage: Record<number, string> = {
  200: 'OK',
  201: 'Created',
  202: 'Accepted',
  204: 'No Content',
  400: 'Bad Request',
  401: 'Unauthorized',
  403: 'Forbidden',
  404: 'Not Found',
  406: 'Not Acceptable',
  410: 'Gone',
  422: 'Unprocessable Entity',
  500: 'Internal Server Error',
  502: 'Bad Gateway',
  503: 'Service Unavailable',
  504: 'Gateway Timeout',
};

interface error {
  name: string;
  data: any;
  type: string;
  response: {
    status: number;
    statusText: string;
    url: string;
  };
}

/**
 * Exception handling procedure
 */
const errorHandler = async (error: error) => {
  // console.log('error: ', error.name);
  // // todo Return user name/password error message
  // if (error.name === 'BizError') {
  //   notification.error({
  //     message: `Request error ${error.data.code}`,
  //     description: error.data.msg,
  //   });
  //   return error.data.code;
  // } else if (error.name === 'SyntaxError') {
  //   notification.error({
  //     message: `Request error ${error.name}`,
  //     description: '',
  //   });
  //   return 500;
  // }
  const { data, response } = error;
  if (!data?.code && response) {
    // Use this approach when（responseData == null OR responseData.code == null）AND（HttpStatus !=200 OR success == false)
    console.log('response: ', response);
    const { status, url, statusText } = response;
    const errortext = codeMessage[status] || statusText;
    notification.error({
      message: `Request error ${status}: ${url}`,
      description: errortext,
    });
  }
  return data;
};
export default errorHandler;
