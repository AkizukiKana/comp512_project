import type { SYSTEM } from '@/services/system/typings';

const SYSTEM_NAME: string = 'SMP_';
const TOKEN_KEY: string = SYSTEM_NAME + 'TOKEN';
const USERINFO_KEY: string = SYSTEM_NAME + 'USERINFO';
const ACTION_KEY: string = SYSTEM_NAME + 'ACTION';
const MENU_KEY: string = SYSTEM_NAME + 'MENU';

// todo Data encryption

export function getToken(): string {
  return window.localStorage.getItem(TOKEN_KEY) || '';
}

export function setToken(token: string) {
  window.localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  window.localStorage.removeItem(TOKEN_KEY);
}

export function getUserInfo(): SYSTEM.LoginResult {
  return JSON.parse(window.localStorage.getItem(USERINFO_KEY) || '') || null;
}

export function setUserInfo(userinfo: SYSTEM.LoginResult) {
  window.localStorage.setItem(USERINFO_KEY, JSON.stringify(userinfo));
}

export function clearUserInfo() {
  window.localStorage.removeItem(USERINFO_KEY);
}

export function getAction(): string[] {
  return JSON.parse(window.localStorage.getItem(ACTION_KEY) || '') || null;
}

export function setAction(action: string[]) {
  window.localStorage.setItem(ACTION_KEY, JSON.stringify(action));
}

export function clearAction() {
  window.localStorage.removeItem(ACTION_KEY);
}

export function getMenu(): any {
  return JSON.parse(window.localStorage.getItem(MENU_KEY) || '') || null;
}

export function setMenu(menu: any) {
  window.localStorage.setItem(MENU_KEY, JSON.stringify(menu));
}

export function clearMenu() {
  window.localStorage.removeItem(MENU_KEY);
}

export function clearLogout() {
  clearToken();
  clearUserInfo();
  clearAction();
  clearMenu();
}
