export function convertPageParams(orgParams: any): any {
  const params = { page: orgParams.current, limit: orgParams.pageSize, ...orgParams };
  delete params.current;
  delete params.pageSize;
  return params;
}
