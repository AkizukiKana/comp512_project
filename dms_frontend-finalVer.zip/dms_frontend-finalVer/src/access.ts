import { getAction } from '@/utils/auth';

/**
 *
 * */
export default function access(initialState: { currentUser?: any | undefined }) {
  const { currentUser } = initialState || {};
  return {
    canAdmin: currentUser && currentUser.userName === 'admin',
  };
}

/**
 * permission check
 * */
export function isGranted(permissionName: string): boolean {
  return getAction().indexOf(permissionName) > -1;
}
