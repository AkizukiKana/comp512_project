import type { Settings as LayoutSettings } from '@ant-design/pro-layout';
import { PageLoading } from '@ant-design/pro-layout';
import type { RunTimeLayoutConfig } from 'umi';

import { history, Link } from 'umi';
import RightContent from '@/components/RightContent';
import Footer from '@/components/Footer';
// import { currentUser as queryCurrentUser } from './services/ant-design-pro/api';
import { BookOutlined, LinkOutlined } from '@ant-design/icons';
import defaultSettings from '../config/defaultSettings';
import type { RequestConfig } from '@@/plugin-request/request';
import type { RequestOptionsInit } from 'umi-request';
import errorHandler from '@/utils/errorHandler';
// import LoadingComponent from "@ant-design/pro-layout/es/PageLoading";
import * as dayjs from 'dayjs';
import 'dayjs/locale/zh-cn'; // Import local language
import moment from 'moment';
import 'moment/locale/zh-cn';

dayjs.locale('zh-cn'); // Use local language
moment.locale('zh-cn');

import type { SYSTEM } from '@/services/system/typings';
// import iconMapping from "@/utils/iconMap";
// import React from "react";
import { handleIconAndComponent } from '@/utils/routes';
// import LoadingComponent from "@ant-design/pro-layout/es/PageLoading";
import {
  getToken,
  getUserInfo,
  clearLogout,
  getMenu,
} from '@/utils/auth';
import { ConfigProvider, message, notification } from 'antd';
import { stringify } from 'querystring';

// const isDev = process.env.NODE_ENV === 'development';
const isDev = false;
const loginPath = '/user/login';

ConfigProvider.config({
  theme: {
    primaryColor: defaultSettings.primaryColor,
  },
});

/** Show loading page when acting slow in getting user info */
export const initialStateConfig = {
  loading: <PageLoading />,
};

const authHeaderInterceptor = (url: string, options: RequestOptionsInit) => {
  if (url.indexOf('/login/') !== -1 || url.indexOf('/logout') !== -1) {
    return {
      url: `${url}`,
      options: { ...options, interceptors: true },
    };
  } else {
    const token = getToken();
    // console.log('url, token: ', url, token);
    let authHeader = {};
    if (token) {
      authHeader = { Authorization: `Bearer ${token}` };
    }

    return {
      url: `${url}`,
      options: { ...options, interceptors: true, headers: authHeader },
    };
  }
};

const demoResponseInterceptors = async (response: Response, r: RequestOptionsInit) => {
  console.log('response: ', response);
  console.log('RequestOptionsInit', r);
  if (r.responseType === 'blob') {
    return response;
  }
  const data = await response.clone().json();
  const resCode = Number(data.code);
  console.log('demoResponseInterceptors data: ', data);
  if (
    resCode &&
    resCode !== 200 &&
    [300, 301, 302, 303, 304, 305, 306, 307, 308, 309].indexOf(resCode) === -1
  ) {
    if (resCode === 401) {
      notification.error({
        message: `Request error ${data.code}`,
        description: 'You have no permission to access this source; login status expired or not logged in, please login again!',
      });
      // await outLogin();
      clearLogout();
      const { query = {}, search, pathname } = history.location;
      const { redirect } = query;
      // Note: There may be security issues, please note
      if (
        window.location.pathname !== '/user/login' &&
        window.location.pathname !== '/user/resetPassword' &&
        !redirect
      ) {
        history.replace({
          pathname: '/user/login',
          search: stringify({
            redirect: pathname + search,
          }),
        });
      }
    } else if (resCode === 99000) {
      notification.error({
          message: `Request error ${resCode}`,
        description: data.message,
      });
      clearLogout();
      const { query = {}, search, pathname } = history.location;
      const { redirect } = query;
      // Note: There may be security issues, please note
      if (
        window.location.pathname !== '/user/login' &&
        window.location.pathname !== '/user/resetPassword' &&
        !redirect
      ) {
        history.replace({
          pathname: '/user/login',
          search: stringify({
            redirect: pathname + search,
          }),
        });
      }
    } else {
      message.error(data.msg);
      // notification.error({
      //   message: `Request error ${resCode}`,
      //   description: data.msg,
      // });
    }
  }
  return response;
};

export const request: RequestConfig = {
  errorHandler,
  // Add request and response interceptors for AccessToken
  requestInterceptors: [authHeaderInterceptor],
  responseInterceptors: [demoResponseInterceptors],
};

/**
 * @see  https://umijs.org/zh-CN/plugins/plugin-initial-state
 * */
export async function getInitialState(): Promise<{
  settings?: Partial<LayoutSettings>;
  currentUser?: any;
  loading?: boolean;
  fetchUserInfo?: () => Promise<any | undefined>;
  fetchMenuInfo?: () => Promise<SYSTEM.Router[] | undefined>;
  fetchCustomerInfo?: (tenantCode: string) => Promise<any | undefined>;
  customMenuData?: SYSTEM.Router[];
}> {
  // dayjs.locale('zh-cn');
  const fetchUserInfo = async () => {
    try {
      const userinfo = getUserInfo();
      return userinfo;
    } catch (error) {
      history.push(loginPath);
    }
    return undefined;
  };

  const fetchMenuInfo = async () => {
    try {
      const menuInfo = getMenu();
      return menuInfo;
    } catch (error) {
      history.push(loginPath);
    }
    return undefined;
  };

  // No execution in login page
  if (
    history.location.pathname !== loginPath
  ) {
    const currentUser = await fetchUserInfo();
    const customMenuData = await fetchMenuInfo();
    return {
      fetchUserInfo,
      fetchMenuInfo,
      currentUser,
      customMenuData,
      settings: defaultSettings,
    };
  } else {
    return {
      fetchUserInfo,
      fetchMenuInfo,
      settings: defaultSettings,
    };
  }
}

// ProLayout https://procomponents.ant.design/components/layout
export const layout: RunTimeLayoutConfig = ({ initialState, setInitialState }) => {
  return {
    menu: {
      // Execute request when initialState?.currentUser?.userid changed
      params: initialState,
      request: async (params: any, defaultMenuData: any) => {
        // console.log('menu params', params);
        // console.log('menu defaultMenuData: ', defaultMenuData);
        // All user info is in initialState.currentUser
        // const menuData = await selectTenant();
        // return menuData;
        const resMenuData = initialState?.customMenuData || [];
        // console.log('resMenuData: ', resMenuData);
        const menus = handleIconAndComponent(resMenuData);
        return menus;
      },
    },
    rightContentRender: () => <RightContent />,
    disableContentMargin: false,
    // waterMarkProps: {
    //   content: initialState?.currentUser?.name,
    // },
    footerRender: () => <Footer />,
    onPageChange: () => {
      const { location } = history;
      // Redirect to login page if not logged in
      if (
        !initialState?.currentUser &&
        location.pathname !== loginPath
      ) {
        history.push(loginPath);
      }
    },
    menuHeaderRender: undefined,
    menuItemRender: (
      menuItemProps: { isUrl: any; path: any; pro_layout_parentKeys: string | any[]; icon: any },
      defaultDom,
    ) => {
      if (menuItemProps.isUrl || !menuItemProps.path) {
        return defaultDom;
      }
      // Second level menu with icon
      return (
        <Link to={menuItemProps.path}>
          {menuItemProps.pro_layout_parentKeys &&
            menuItemProps.pro_layout_parentKeys.length > 0 &&
            menuItemProps.icon}
          {defaultDom}
        </Link>
      );
    },
    // Customized 403 page
    // unAccessible: <div>unAccessible</div>,
    // Add loading status
    childrenRender: (children: any, props: { location: { pathname: string | string[] } }) => {
      // if (initialState?.loading) return <PageLoading />;
      return (
        <>
          {children}
          {/* {!props.location?.pathname?.includes('/login') ? (
            <SettingDrawer
              enableDarkTheme
              settings={initialState?.settings}
              onSettingChange={(settings) => {
                setInitialState((preInitialState: any) => ({
                  ...preInitialState,
                  settings,
                }));
              }}
            />
          ) : (
            <SettingDrawer
              enableDarkTheme
              settings={initialState?.settings}
              themeOnly={true}
              onSettingChange={(settings) => {
                setInitialState((preInitialState: any) => ({
                  ...preInitialState,
                  settings,
                }));
              }}
            />
          )} */}
        </>
      );
    },
    ...initialState?.settings,
  };
};
