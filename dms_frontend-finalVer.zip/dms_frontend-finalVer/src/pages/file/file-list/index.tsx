import { SYSTEM } from "@/services/system/typings";
import { PageContainer } from '@ant-design/pro-layout';
import ProTable, { ActionType, ProColumns } from '@ant-design/pro-table';
import { FormInstance } from '@ant-design/pro-form';
import React, { useRef, useState } from 'react';
import { Button, Drawer, message, Popconfirm, Upload } from "antd";
import { ImportOutlined, InboxOutlined } from "@ant-design/icons";
import { closeShare, fileDownload, fileUpload, getFileInfoPage, openShare, removeFile } from "@/services/swagger/file-info";
import type { RcFile, UploadProps } from 'antd/lib/upload';

const FileList: React.FC = () => {
  const actionRef = useRef<ActionType>();
  const formRef = useRef<FormInstance>();
  // Upload
  const { Dragger } = Upload;
  const [fileList, setFileList] = useState<RcFile[]>([]);
  const [showUpload, setShowUpload] = useState<boolean>(false);

  // Upload properties
  const uploadProps: UploadProps = {
    name: 'file',
    accept:
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel',
    multiple: false,
    showUploadList: false,
    beforeUpload: (file) => {
      setFileList([file]);
    },
    onChange(info) { },
    onDrop(e) {
      console.log('Dropped files', e.dataTransfer.files);
    },
  };

  const columns: ProColumns<any>[] = [
    // Index
    {
      title: '#',
      dataIndex: 'index',
      valueType: 'index',
      width: 24,
    },
    // File name
    {
      title: 'File Name',
      dataIndex: 'fileName',
      fieldProps: {
        placeholder: 'Please enter',
      },
    },
    // File type
    {
      title: 'File Type',
      dataIndex: 'fileType',
      fieldProps: {
        placeholder: 'Please enter',
      },
    },
    // Create time
    {
      title: 'Create Time',
      dataIndex: 'createTime',
      hideInSearch: true,
      valueType: 'dateTime'
    },
    // Shared flag
    {
      title: 'Shared',
      dataIndex: 'sharedFlag',
      hideInSearch: true,
      render: (dom, entity) => (
        <span>{entity.sharedFlag ? 'Yes' : 'No'}</span>
      )
    },
    // Options
    {
      title: 'Option',
      dataIndex: 'option',
      valueType: 'option',
      fixed: 'right',
      render: (text, record, _, action) => [
        <a
          key='fileDownload'
          onClick={async () => {
            await fileDownload(record.id);
          }}
        >
          Download
        </a>,
        <a
          key='removeFile'
          onClick={async () => {
            await removeFile(record.id);
            actionRef.current?.reload();
          }}
        >
          Remove
        </a>,
        !record.sharedFlag ? (
          <Popconfirm
            key="openShare"
            title="Share this file?"
            onConfirm={async () => {
              await openShare(record.id);
              actionRef.current?.reload();
            }}
            onCancel={() => { }}
            okText="Confirm"
            cancelText="Cancel"
          >
            <a key="openShareA">Share</a>
          </Popconfirm>
        ) : (''),
        record.sharedFlag ? (
          <Popconfirm
            key="closeShare"
            title="Cancel Sharing?"
            onConfirm={async () => {
              await closeShare(record.id);
              actionRef.current?.reload();
            }}
            onCancel={() => { }}
            okText="Confirm"
            cancelText="Cancel"
          >
            <a key="closeShareA">Cancel Share</a>
          </Popconfirm>
        ) : ('')
      ],
    },
  ];

  return (
    <PageContainer>
      <ProTable<any, SYSTEM.PageParams>
        columns={columns}
        actionRef={actionRef}
        formRef={formRef}
        rowKey='id'
        scroll={{ x: 1000 }}
        search={{
          searchText: 'Search',
          resetText: 'Reset',
          labelWidth: 120,
        }}
        locale={{
          emptyText: 'loading...'
        }}
        options={false}
        pagination={{
          pageSize: 10,
          showSizeChanger: false,
          showQuickJumper: false,
          showTotal: (total: number, range: [number, number]) => (
            <>
              {range[0]}-{range[1]} of {total} items
            </>
          )
        }}
        request={async (params) => {
          params.current = Number(params.current) - 1;
          const res = await getFileInfoPage(params);
          return {
            data: res.data.items,
            success: res.success,
            total: res.data.total,
          };
        }}
        toolBarRender={() => [
          <Button
            key='import'
            onClick={async () => {
              setShowUpload(true);
            }}
          >
            <ImportOutlined /> Upload File
          </Button>
        ]}
      />
      <Drawer
        title="Import File"
        width={600}
        open={showUpload}
        onClose={() => {
          setShowUpload(false);
        }}
        closable={true}
      >
        <>
          <Dragger height={200} {...uploadProps}>
            <p className="ant-upload-drag-icon">
              <InboxOutlined />
            </p>
            <p className="ant-upload-text">Select or drag file you wish to share</p>
            <p className="ant-upload-hint">Import File</p>
          </Dragger>

          <Popconfirm
            // Import
            title={
              <>
                <span>
                  <b>Import Confirmation</b>
                </span>
                <li>Maximum file size: 100MB</li>
              </>
            }
            onConfirm={async () => {
              if (fileList && fileList.length > 0) {
                const formData = new FormData();
                fileList.forEach(s => {
                  formData.append('files', s);
                })

                const res = await fileUpload(formData);
                if (res?.success) {
                  message.success(`file import successful`);
                }

                setFileList([]);
                actionRef.current?.reload?.();
              }
            }}
            onCancel={() => { }}
            okText="Upload"
            cancelText="Cancel"
            disabled={fileList.length == 0}
          >
            <Button
              style={{ marginTop: 10 }}
              type="primary"
              disabled={fileList.length == 0}
              block
            >
              Upload
            </Button>
          </Popconfirm>
        </>
      </Drawer>
    </PageContainer>
  );
}

export default FileList;
