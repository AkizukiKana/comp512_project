import { SYSTEM } from "@/services/system/typings";
import { PageContainer } from '@ant-design/pro-layout';
import ProTable, { ActionType, ProColumns } from '@ant-design/pro-table';
import { FormInstance } from '@ant-design/pro-form';
import React, { useRef } from 'react';
import { fileDownload, getShareFileInfoPage } from "@/services/swagger/file-info";

const SharedFileList: React.FC = () => {
  const actionRef = useRef<ActionType>();
  const formRef = useRef<FormInstance>();

  const columns: ProColumns<any>[] = [
    // Index
    {
      title: '#',
      dataIndex: 'index',
      valueType: 'index',
      width: 24,
    },
    // File name
    {
      title: 'File Name',
      dataIndex: 'fileName',
      fieldProps: {
        placeholder: 'Please enter',
      },
    },
    // File type
    {
      title: 'File Type',
      dataIndex: 'fileType',
      fieldProps: {
        placeholder: 'Please enter',
      },
    },
    // Create time
    {
      title: 'Create Time',
      dataIndex: 'createTime',
      hideInSearch: true,
      valueType: 'dateTime'
    },
    // Options
    {
      title: 'Option',
      dataIndex: 'option',
      valueType: 'option',
      fixed: 'right',
      render: (text, record, _, action) => [
        <a
          key='fileDownload'
          onClick={async () => {
            await fileDownload(record.id);
          }}
        >
          Download
        </a>
      ],
    },
  ];

  return (
    <PageContainer>
      <ProTable<any, SYSTEM.PageParams>
        columns={columns}
        actionRef={actionRef}
        formRef={formRef}
        rowKey='id'
        scroll={{ x: 1000 }}
        search={{
          searchText: 'Search',
          resetText: 'Reset',
          labelWidth: 120,
        }}
        locale={{
          emptyText: 'loading...'
        }}
        options={false}
        pagination={{
          pageSize: 10,
          showSizeChanger: false,
          showQuickJumper: false,
          showTotal: (total: number, range: [number, number]) => (
            <>
              {range[0]}-{range[1]} of {total} items
            </>
          )
        }}
        request={async (params) => {
          params.current = Number(params.current) - 1;
          const res = await getShareFileInfoPage(params);
          return {
            data: res.data.items,
            success: res.success,
            total: res.data.total,
          };
        }}
      />
    </PageContainer>
  );
}

export default SharedFileList;
