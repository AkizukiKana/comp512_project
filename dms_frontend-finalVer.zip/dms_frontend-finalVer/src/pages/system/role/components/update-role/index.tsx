import { getPermissionOptions } from '@/services/swagger/permission';
import { getRoleEdit } from '@/services/swagger/role';
import { ProFormCheckbox } from '@ant-design/pro-components';
import { ModalForm, ProFormText } from '@ant-design/pro-form';
import classNames from 'classnames';
import styles from './index.less';

export type FormValueType = {
  target?: string;
  template?: string;
  type?: string;
  time?: string;
  frequency?: string;
};

export type UpdateRoleModalFormProps = {
  roleId: number;
  modalVisible: boolean;
  onCancel: (flag?: boolean, formVals?: FormValueType) => void;
  onSubmit: (values: FormValueType) => Promise<void>;
};

const UpdateRoleModalForm: React.FC<UpdateRoleModalFormProps> = (props) => {

  return (
    <>
      <ModalForm
        className={classNames(styles.container)}
        width='30%'
        modalProps={{ destroyOnClose: true }}
        visible={props.modalVisible}
        onVisibleChange={props.onCancel}
        onFinish={props.onSubmit}
        submitter={{
          searchConfig: {
            submitText: 'save'
          },
          render: (prop, defaultDoms) => {
            return [
              defaultDoms[1]
            ];
          },
        }}
        request={async () => {
          const res = await getRoleEdit(props.roleId);
          return res.data;
        }}
      >
         <ProFormText
          width='sm'
          name='name'
          readonly={true}
          label='Name'
          placeholder = {'Please enter'}
        />
         <ProFormText
          width='sm'
          name='displayName'
          label='Display Name'
          placeholder = {'Please enter'}
          rules={[{ required: true, message: 'Required' }]}
        />
        <ProFormCheckbox.Group
          name="permissionList"
          label="Permission"
          rules={[{ required: true, message: 'Choose at least one' }]}
          request={async () => {
            const roleOptions = await getPermissionOptions();
            return roleOptions.data.items;
          }}
        />
      </ModalForm>
    </>
  )
}

export default UpdateRoleModalForm;
