import { SYSTEM } from "@/services/system/typings";
import { PageContainer } from '@ant-design/pro-layout';
import ProTable, { ActionType, ProColumns } from '@ant-design/pro-table';
import { FormInstance } from '@ant-design/pro-form';
import React, { useRef, useState } from 'react';
import { isGranted } from "@/access";
import { Button, Popconfirm } from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { createRole, deleteRole, getRolePage, updateRole } from "@/services/swagger/role";
import CreateRoleModalForm from "./components/create-role";
import UpdateRoleModalForm from "./components/update-role";

const Role: React.FC = () => {
  const actionRef = useRef<ActionType>();
  const formRef = useRef<FormInstance>();
  // modal
  const [createModalVisible, handleCreateModalVisible] = useState<boolean>(false);
  const [updateModalVisible, handleUpdateModalVisible] = useState<boolean>(false);
  const [updateRoleId, setUpdateRoleId] = useState<number>(0);

  const columns: ProColumns<any>[] = [
    // Index
    {
      title: '#',
      dataIndex: 'index',
      valueType: 'index',
      width: 24,
    },
    // Name filter
    {
      title: 'Filter',
      dataIndex: 'filter',
      hideInTable: true,
      fieldProps: {
        placeholder: 'Please enter',
      },
    },
    // Name
    {
      title: 'Name',
      dataIndex: 'name',
      hideInSearch: true,
    },
    // Display name
    {
      title: 'Display Name',
      dataIndex: 'displayName',
      hideInSearch: true,
    },
    // Options
    {
      title: 'Option',
      dataIndex: 'option',
      valueType: 'option',
      fixed: 'right',
      render: (text, record, _, action) => [
        isGranted('admin') && (
          <a
            key='updateRole'
            onClick={() => {
              setUpdateRoleId(record.id);
              handleUpdateModalVisible(true);
            }}
          >
            Update
          </a>
        ),
        isGranted('admin') && (
          <Popconfirm
            key="deleteRole"
            title="Delete Role?"
            onConfirm={async () => {
              await deleteRole(record.id);
              actionRef.current?.reload();
            }}
            onCancel={() => { }}
            okText="Confirm"
            cancelText="Cancel"
          >
            <a key="deleteRoleA">Delete</a>
          </Popconfirm>
        ),
      ],
    },
  ]

  return (
    <PageContainer>
      <ProTable<any, SYSTEM.PageParams>
        columns={columns}
        actionRef={actionRef}
        formRef={formRef}
        rowKey='id'
        scroll={{ x: 1000 }}
        search={{
          searchText: 'Search',
          resetText: 'Reset',
          labelWidth: 120,
        }}
        locale={{
          emptyText: 'loading...'
        }}
        options={false}
        pagination={{
          pageSize: 10,
          showSizeChanger: false,
          showQuickJumper: false,
          showTotal: (total: number, range: [number, number]) => (
            <>
              {range[0]}-{range[1]} of {total} items
            </>
          )
        }}
        request={async (params) => {
          params.current = Number(params.current) - 1;
          const res = await getRolePage(params);
          return {
            data: res.data.items,
            success: res.success,
            total: res.data.total,
          };
        }}
        toolBarRender={() => [
          isGranted('admin') && (
            <>
              <Button
                key='createRole'
                onClick={async () => {
                  handleCreateModalVisible(true);
                }}
              >
                <PlusOutlined /> Create
              </Button>
            </>
          ),
        ]}
      />
      <CreateRoleModalForm
        modalVisible={createModalVisible}
        onSubmit={async (value) => {
          await createRole(value);
          actionRef.current?.reload();
          handleCreateModalVisible(false);
        }}
        onCancel={(value: boolean | undefined) => {
          if (!value) {
            handleCreateModalVisible(false);
          }
        }}
      />
      <UpdateRoleModalForm
        roleId={updateRoleId}
        modalVisible={updateModalVisible}
        onSubmit={async (value) => {
          await updateRole({ ...value, id: updateRoleId });
          actionRef.current?.reload();
          handleUpdateModalVisible(false);
        }}
        onCancel={(value: boolean | undefined) => {
          if (!value) {
            handleUpdateModalVisible(false);
          }
        }}
      />
    </PageContainer>
  );
}

export default Role;
