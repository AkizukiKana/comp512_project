import { getRoleOptions } from '@/services/swagger/role';
import { getUserEdit } from '@/services/swagger/user';
import { ProFormCheckbox } from '@ant-design/pro-components';
import { ModalForm, ProFormText } from '@ant-design/pro-form';
import classNames from 'classnames';
import styles from './index.less';

export type FormValueType = {
  target?: string;
  template?: string;
  type?: string;
  time?: string;
  frequency?: string;
};

export type UpdateUserModalFormProps = {
  userId: number;
  modalVisible: boolean;
  onCancel: (flag?: boolean, formVals?: FormValueType) => void;
  onSubmit: (values: FormValueType) => Promise<void>;
};

const UpdateUserModalForm: React.FC<UpdateUserModalFormProps> = (props) => {

  return (
    <>
      <ModalForm
        className={classNames(styles.container)}
        width='30%'
        modalProps={{ destroyOnClose: true }}
        visible={props.modalVisible}
        onVisibleChange={props.onCancel}
        onFinish={props.onSubmit}
        submitter={{
          searchConfig: {
            submitText: 'save'
          },
          render: (prop, defaultDoms) => {
            return [
              defaultDoms[1]
            ];
          },
        }}
        request={async () => {
          const res = await getUserEdit(props.userId);
          return res.data;
        }}
      >
        <ProFormText
          width='sm'
          name='userName'
          readonly={true}
          label='User Name'
          placeholder = {'Please enter'}
        />
        <ProFormText.Password
          width='sm'
          name='password'
          label='Password'
          placeholder = {'Please enter'}
          rules={[{ required: true, message: 'Required' }]}
        />
        <ProFormText
          width='sm'
          name='name'
          label='Name'
          placeholder = {'Please enter'}
          rules={[{ required: true, message: 'Required' }]}
        />
        <ProFormText
          width='sm'
          name='emailAddress'
          label='Email Address'
          placeholder = {'Please enter'}
          rules={[{ required: true, message: 'Required' }]}
        />
        <ProFormText
          width='sm'
          name='phoneNumber'
          label='Phone Number'
          placeholder = {'Please enter'}
        />

        <ProFormCheckbox.Group
          name="assignedRoleNameList"
          label="Assigned Role"
          rules={[{ required: true, message: 'Choose at least one' }]}
          request={async () => {
            const roleOptions = await getRoleOptions();
            return roleOptions.data.items;
          }}
        />
      </ModalForm>
    </>
  )
}

export default UpdateUserModalForm;
