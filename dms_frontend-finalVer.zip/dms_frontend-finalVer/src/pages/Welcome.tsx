import React from 'react';
import { Result } from 'antd';

const Welcome: React.FC = () => (
  <Result status="500" title="Welcome to DMS" subTitle="Intelligent·Effcient·Convenient" />
);

export default Welcome;
