import { LockOutlined, UserOutlined } from '@ant-design/icons';
import { message, Tabs } from 'antd';
import React, { useEffect, useRef, useState } from 'react';
import type { ProFormInstance } from '@ant-design/pro-form';
import { ProFormCheckbox, ProFormText, LoginForm } from '@ant-design/pro-form';
import { history, useModel } from 'umi';
import Footer from '@/components/Footer';
import { login } from '@/services/system/login';
import styles from './index.less';
import type { SYSTEM } from '@/services/system/typings';
import { setAction, setMenu, setToken, setUserInfo } from '@/utils/auth';

const Login: React.FC = () => {
  const [type, setType] = useState<string>('account');
  const { initialState, setInitialState } = useModel('@@initialState');
  const loginFormRef = useRef<ProFormInstance<SYSTEM.LoginParams>>();

  useEffect(() => { }, []);

  const fetchUserInfo = async (data: any) => {
    const userInfo = data;

    if (userInfo) {
      setUserInfo(userInfo);
      setToken(userInfo.token || '');
      setAction(userInfo.grantedPermissionList || []);
      setMenu(userInfo.menuList);
      await setInitialState((s: any) => ({ ...s, currentUser: userInfo, customMenuData: userInfo.menuList }));
    }
  };

  const handleSubmit = async (values: SYSTEM.LoginParams) => {
    try {
      const msg = await login({ ...values });

      if (msg?.code === 200) {
        await fetchUserInfo(msg.data); // Current user info

        if (!history) return;
        const { query } = history.location;
        const { redirect } = query as {
          redirect: string;
        };
        history.push(redirect || '/');
      }
    } catch (error) {
      console.log('login error ', error);
      message.error('Login failed, please retry!');
    }
  };

  const tabs = [{ label: 'Account Password', key: 'account' }];

  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <LoginForm
          formRef={loginFormRef}
          logo={
            <img
              alt="logo"
              style={{
                width: '48px',
                height: '48px',
              }}
              src="/favicon.ico"
            />
          }
          title="DMS"
          submitter={{
            searchConfig: {
              submitText: 'Login'
            }
          }}
          onFinish={async (values) => {
            await handleSubmit(values as SYSTEM.LoginParams);
          }}
        >
          <Tabs activeKey={type} onChange={setType} items={tabs} />
          {type === 'account' && (
            <>
              <ProFormText
                name="userName"
                fieldProps={{
                  size: 'large',
                  prefix: <UserOutlined className={styles.prefixIcon} />,
                }}
                placeholder={'User Name'}
                rules={[
                  {
                    required: true,
                    message: 'Please enter user name',
                  },
                ]}
              />
              <ProFormText.Password
                name="password"
                fieldProps={{
                  size: 'large',
                  prefix: <LockOutlined className={styles.prefixIcon} />,
                }}
                placeholder={'Password'}
                rules={[
                  {
                    required: true,
                    message: 'Please enter password',
                  },
                ]}
              />

              <div
                style={{
                  marginTop: 24,
                  marginBottom: 24,
                }}
              >
                <ProFormCheckbox noStyle name="rememberMe">
                  Remember Me
                </ProFormCheckbox>
              </div>
            </>
          )}
        </LoginForm>
      </div>
      <Footer />
    </div>
  );
};

export default Login;
