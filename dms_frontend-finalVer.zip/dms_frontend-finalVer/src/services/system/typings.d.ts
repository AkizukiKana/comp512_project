import type React from 'react';

declare namespace SYSTEM {
  type Router = {
    name?: string;
    path?: string;
    hideInMenu?: boolean;
    redirect?: string;
    component?: string;
    routes?: Router[];
    icon?: React.ReactNode;
    iconName?: string;
    isFrame?: string;
    target?: string;
  };
  type LoginResult = {
    code?: number;
    msg?: string;
    data?: {
      token?: string;
      userName?: string;
      grantedPermissionList?: string[];
    };
  };
  type LoginParams = {
    userName?: string;
    password?: string;
    rememberMe?: boolean;
  };
  type PageParams = {
    current?: number | 0;
    pageSize?: number | 10;
  };
  type ResponseResult = {
    msg: string;
    code: number;
    data?: any;
    success: boolean;
  };
}
