import { request } from '@@/plugin-request/request';
import type { SYSTEM } from '@/services/system/typings';

const authApi = '/dms/auth';

/** POST /auth/login */
export async function login(body: SYSTEM.LoginParams, options?: { [key: string]: any }) {
  return request<SYSTEM.LoginResult>(authApi + '/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}
