import { request } from '@@/plugin-request/request';
import type { SYSTEM } from '@/services/system/typings';
import { convertPageParams } from '@/utils/page';

const roleApi = '/dms/api/role';

/** Create role */
export async function createRole(body: any) {
  return request<SYSTEM.ResponseResult>(roleApi + '/create', {
    method: 'POST',
    data: body
  });
}

/** Get role options */
export async function getRoleOptions() {
  return request<SYSTEM.ResponseResult>(roleApi + '/options', {
    method: 'GET'
  });
}

/** Get role page */
export async function getRolePage(params: any) {
  return request<SYSTEM.ResponseResult>(roleApi + '/page', {
    method: 'GET',
    params: convertPageParams(params)
  });
}

/** Update role */
export async function updateRole(body: any) {
  return request<SYSTEM.ResponseResult>(roleApi + '/update', {
    method: 'POST',
    data: body
  });
}

/** Delete role */
export async function deleteRole(id: any) {
  return request<SYSTEM.ResponseResult>(roleApi + '/delete', {
    method: 'DELETE',
    params: { id: id }
  });
}

export async function getRoleEdit(id: number) {
  return request<SYSTEM.ResponseResult>(roleApi + '/edit', {
    method: 'GET',
    params: { id: id }
  });
}
