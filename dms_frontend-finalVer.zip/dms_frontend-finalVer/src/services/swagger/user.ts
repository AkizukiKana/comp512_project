import { request } from '@@/plugin-request/request';
import type { SYSTEM } from '@/services/system/typings';
import { convertPageParams } from '@/utils/page';

const userApi = '/dms/api/user';

/** Create user */
export async function createUser(body: any) {
  return request<SYSTEM.ResponseResult>(userApi + '/create', {
    method: 'POST',
    data: body
  });
}

/** Get user page */
export async function getUserPage(params: any) {
  return request<SYSTEM.ResponseResult>(userApi + '/page', {
    method: 'GET',
    params: convertPageParams(params)
  });
}

/** Update user */
export async function updateUser(body: any) {
  return request<SYSTEM.ResponseResult>(userApi + '/update', {
    method: 'POST',
    data: body
  });
}

/** Delete user */
export async function deleteUser(id: any) {
  return request<SYSTEM.ResponseResult>(userApi + '/delete', {
    method: 'DELETE',
    params: { id: id }
  });
}

export async function getUserEdit(id: number) {
  return request<SYSTEM.ResponseResult>(userApi + '/edit', {
    method: 'GET',
    params: { id: id }
  });
}
