import { request } from '@@/plugin-request/request';
import type { SYSTEM } from '@/services/system/typings';

const permissionApi = '/dms/api/permission';

export async function getPermissionOptions() {
  return request<SYSTEM.ResponseResult>(permissionApi + '/options', {
    method: 'GET'
  });
}