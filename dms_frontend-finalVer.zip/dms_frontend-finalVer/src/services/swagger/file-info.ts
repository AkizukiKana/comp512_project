import type { SYSTEM } from '@/services/system/typings';
import { getToken } from '@/utils/auth';
import { convertPageParams } from '@/utils/page';
import { request } from '@@/plugin-request/request';
import saveAs from 'file-saver';

const api = '/dms/api/fileInfo';

/** Get files */
export async function getFileInfoPage(params: any) {
  return request<SYSTEM.ResponseResult>(api + '/page', {
    method: 'GET',
    params: convertPageParams(params)
  });
}

/** Upload files */
export async function fileUpload(body: any) {
  return request<SYSTEM.ResponseResult>(api + '/upload', {
    method: 'POST',
    data: body
  });
}

/** Download files */
export async function fileDownload(fileInfoId: number) {
  fetch(
    api + '/download?fileInfoId=' + fileInfoId,
    {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${getToken()}`
      }
    }
  )
    .then(async (res) => {
      const blob = await res.blob();
      const contentDisposition = window.decodeURI(res.headers.get('Content-Disposition') || '');
      const fileName = contentDisposition.split('filename=')[1];
      saveAs(blob, fileName);
    });
}

/** Share files */
export async function openShare(fileInfoId: number) {
  return request<SYSTEM.ResponseResult>(api + '/openShare', {
    method: 'POST',
    params: { fileInfoId: fileInfoId }
  });
}

/** Cancel sharing files */
export async function closeShare(fileInfoId: number) {
  return request<SYSTEM.ResponseResult>(api + '/closeShare', {
    method: 'POST',
    params: { fileInfoId: fileInfoId }
  });
}

/** Get shared files */
export async function getShareFileInfoPage(params: any) {
  return request<SYSTEM.ResponseResult>(api + '/sharePage', {
    method: 'GET',
    params: convertPageParams(params)
  });
}

/** remove file */
export async function removeFile(fileInfoId: number) {
  return request<SYSTEM.ResponseResult>(api + '/remove', {
    method: 'DELETE',
    params: { fileInfoId: fileInfoId }
  });
}
